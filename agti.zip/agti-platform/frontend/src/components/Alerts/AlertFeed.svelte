<script>
    import { onMount } from 'svelte';
    import { alertStore } from '../../stores/alertStore.js';
    import AlertItem from './AlertItem.svelte';
    
    // Local state
    let currentLanguage = 'en';
    let alertFilter = 'all';
    let showSettings = false;
    
    // Filter alerts based on selected filter
    $: filteredAlerts = $alertStore.alerts.filter(alert => {
        if (alertFilter === 'all') return true;
        if (alertFilter === 'critical') return alert.priority === 'critical';
        if (alertFilter === 'options') return alert.type === 'options';
        if (alertFilter === 'news') return alert.type === 'news';
        if (alertFilter === 'market') return alert.type === 'market';
        return true;
    });
    
    // Language options
    const languages = [
        { code: 'en', name: 'English' },
        { code: 'gu', name: 'ગુજરાતી (Gujarati)' }
    ];
    
    // Alert type options
    const alertTypes = [
        { value: 'all', label: 'All Alerts' },
        { value: 'critical', label: 'Critical Only' },
        { value: 'options', label: 'Options Alerts' },
        { value: 'news', label: 'News Alerts' },
        { value: 'market', label: 'Market Alerts' }
    ];
    
    onMount(() => {
        // Load saved language preference
        const savedLanguage = localStorage.getItem('preferredLanguage') || 'en';
        currentLanguage = savedLanguage;
        
        // Start polling for new alerts
        alertStore.startPolling();
    });
    
    function toggleSettings() {
        showSettings = !showSettings;
    }
    
    function setLanguage(code) {
        currentLanguage = code;
        localStorage.setItem('preferredLanguage', code);
    }
    
    function clearAllAlerts() {
        alertStore.clearAlerts();
    }
</script>

<div class="alert-feed">
    <div class="alert-header">
        <h3>Alerts & Notifications</h3>
        <div class="alert-actions">
            <button class="icon-button" on:click={toggleSettings} title="Alert Settings">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <circle cx="12" cy="12" r="3"></circle>
                    <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path>
                </svg>
            </button>
            <button class="icon-button" on:click={clearAllAlerts} title="Clear All Alerts">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <polyline points="3 6 5 6 21 6"></polyline>
                    <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
                </svg>
            </button>
        </div>
    </div>
    
    {#if showSettings}
        <div class="alert-settings">
            <div class="settings-group">
                <label>Language</label>
                <div class="language-options">
                    {#each languages as language}
                        <button 
                            class="language-button" 
                            class:active={currentLanguage === language.code}
                            on:click={() => setLanguage(language.code)}
                        >
                            {language.name}
                        </button>
                    {/each}
                </div>
            </div>
            
            <div class="settings-group">
                <label>Filter Alerts</label>
                <select bind:value={alertFilter}>
                    {#each alertTypes as type}
                        <option value={type.value}>{type.label}</option>
                    {/each}
                </select>
            </div>
        </div>
    {/if}
    
    <div class="alert-list" class:empty={filteredAlerts.length === 0}>
        {#if filteredAlerts.length === 0}
            <div class="no-alerts">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="36" height="36" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M22 17H2a3 3 0 0 0 3-3V9a7 7 0 0 1 14 0v5a3 3 0 0 0 3 3zm-8.27 4a2 2 0 0 1-3.46 0"></path>
                </svg>
                <p>{currentLanguage === 'en' ? 'No alerts to display' : 'પ્રદર્શિત કરવા માટે કોઈ સૂચનાઓ નથી'}</p>
            </div>
        {:else}
            {#each filteredAlerts as alert (alert.id)}
                <AlertItem {alert} language={currentLanguage} />
            {/each}
        {/if}
    </div>
</div>

<style>
    .alert-feed {
        background: var(--bg-card);
        border-radius: 12px;
        padding: 1rem;
        height: 100%;
        display: flex;
        flex-direction: column;
        box-shadow: var(--shadow-sm);
    }
    
    .alert-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 1rem;
    }
    
    .alert-header h3 {
        margin: 0;
        font-size: 1.1rem;
        font-weight: 600;
    }
    
    .alert-actions {
        display: flex;
        gap: 0.5rem;
    }
    
    .icon-button {
        background: transparent;
        border: none;
        cursor: pointer;
        color: var(--text-secondary);
        display: flex;
        align-items: center;
        justify-content: center;
        width: 32px;
        height: 32px;
        border-radius: 6px;
        transition: background-color 0.2s;
    }
    
    .icon-button:hover {
        background: var(--bg-hover);
        color: var(--text-primary);
    }
    
    .alert-settings {
        background: var(--bg-light);
        border-radius: 8px;
        padding: 1rem;
        margin-bottom: 1rem;
        display: flex;
        flex-direction: column;
        gap: 1rem;
    }
    
    .settings-group {
        display: flex;
        flex-direction: column;
        gap: 0.5rem;
    }
    
    .settings-group label {
        font-size: 0.9rem;
        color: var(--text-secondary);
    }
    
    .language-options {
        display: flex;
        gap: 0.5rem;
    }
    
    .language-button {
        background: var(--bg-input);
        border: 1px solid var(--border-color);
        border-radius: 4px;
        padding: 0.25rem 0.75rem;
        font-size: 0.9rem;
        cursor: pointer;
        color: var(--text-primary);
        transition: all 0.2s;
    }
    
    .language-button.active {
        background: var(--primary);
        color: white;
        border-color: var(--primary);
    }
    
    select {
        background: var(--bg-input);
        border: 1px solid var(--border-color);
        border-radius: 4px;
        padding: 0.5rem;
        font-size: 0.9rem;
        color: var(--text-primary);
    }
    
    .alert-list {
        flex: 1;
        overflow-y: auto;
        display: flex;
        flex-direction: column;
        gap: 0.75rem;
    }
    
    .alert-list.empty {
        display: flex;
        align-items: center;
        justify-content: center;
    }
    
    .no-alerts {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        color: var(--text-secondary);
        height: 100%;
        opacity: 0.7;
    }
    
    .no-alerts p {
        margin-top: 1rem;
        font-size: 0.9rem;
    }
</style>
