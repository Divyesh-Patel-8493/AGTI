<script>
    export let alert;
    export let language = 'en';
    
    // Determine alert color based on priority
    function getAlertColor(priority) {
        switch (priority) {
            case 'critical':
                return 'alert-critical';
            case 'high':
                return 'alert-high';
            case 'normal':
                return 'alert-normal';
            case 'low':
                return 'alert-low';
            default:
                return 'alert-normal';
        }
    }
    
    // Format timestamp
    function formatTime(timestamp) {
        const date = new Date(timestamp);
        return date.toLocaleTimeString(language === 'en' ? 'en-IN' : 'gu-IN', {
            hour: '2-digit',
            minute: '2-digit'
        });
    }
    
    // Check if this alert should show Gujarati content
    $: showGujarati = language === 'gu' && alert.message_gujarati;
    
    // Get alert icon based on type
    function getAlertIcon(type) {
        switch (type) {
            case 'options':
                return `
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M18 8h1a4 4 0 0 1 0 8h-1"></path>
                        <path d="M2 8h16v9a4 4 0 0 1-4 4H6a4 4 0 0 1-4-4V8z"></path>
                        <line x1="6" y1="1" x2="6" y2="4"></line>
                        <line x1="10" y1="1" x2="10" y2="4"></line>
                        <line x1="14" y1="1" x2="14" y2="4"></line>
                    </svg>
                `;
            case 'news':
                return `
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M19 20H5a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v1"></path>
                        <path d="M18 14v-3"></path>
                        <path d="M18 17h.01"></path>
                        <path d="M17 11H7"></path>
                        <path d="M17 8H7"></path>
                    </svg>
                `;
            case 'market':
                return `
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <polyline points="22 7 13.5 15.5 8.5 10.5 2 17"></polyline>
                        <polyline points="16 7 22 7 22 13"></polyline>
                    </svg>
                `;
            default:
                return `
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <circle cx="12" cy="12" r="10"></circle>
                        <line x1="12" y1="8" x2="12" y2="12"></line>
                        <line x1="12" y1="16" x2="12.01" y2="16"></line>
                    </svg>
                `;
        }
    }
</script>

<div class="alert-item {getAlertColor(alert.priority)}">
    <div class="alert-header">
        <div class="alert-type">
            {@html getAlertIcon(alert.type)}
            <span>{alert.type.toUpperCase()}</span>
        </div>
        <div class="alert-time">{formatTime(alert.timestamp)}</div>
    </div>
    
    <div class="alert-content">
        <div class="alert-title">
            {showGujarati ? alert.title_gujarati : alert.title}
        </div>
        <div class="alert-message">
            {showGujarati ? alert.message_gujarati : alert.message}
        </div>
    </div>
    
    {#if alert.symbol}
        <div class="alert-details">
            <div class="alert-symbol">
                {alert.symbol}
                {#if alert.strike}
                    <span class="strike-price">{alert.strike} {alert.optionType || ''}</span>
                {/if}
            </div>
            
            {#if alert.action && (alert.action === 'BUY' || alert.action === 'SELL')}
                <div class="alert-action {alert.action === 'BUY' ? 'action-buy' : 'action-sell'}">
                    {alert.action}
                </div>
            {/if}
        </div>
    {/if}
</div>

<style>
    .alert-item {
        padding: 0.75rem;
        border-radius: 8px;
        display: flex;
        flex-direction: column;
        gap: 0.5rem;
        border-left: 4px solid transparent;
        background: var(--bg-light);
        box-shadow: var(--shadow-xs);
        animation: slide-in 0.3s ease-out;
    }
    
    .alert-critical {
        border-left-color: var(--danger);
        background: rgba(220, 53, 69, 0.05);
    }
    
    .alert-high {
        border-left-color: var(--warning);
        background: rgba(255, 193, 7, 0.05);
    }
    
    .alert-normal {
        border-left-color: var(--primary);
        background: rgba(0, 123, 255, 0.05);
    }
    
    .alert-low {
        border-left-color: var(--success);
        background: rgba(40, 167, 69, 0.05);
    }
    
    .alert-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        font-size: 0.8rem;
    }
    
    .alert-type {
        display: flex;
        align-items: center;
        gap: 0.25rem;
        font-weight: 500;
        color: var(--text-secondary);
    }
    
    .alert-time {
        font-size: 0.75rem;
        color: var(--text-muted);
    }
    
    .alert-content {
        display: flex;
        flex-direction: column;
        gap: 0.25rem;
    }
    
    .alert-title {
        font-weight: 600;
        font-size: 0.95rem;
    }
    
    .alert-message {
        font-size: 0.85rem;
        color: var(--text-secondary);
        line-height: 1.4;
    }
    
    .alert-details {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-top: 0.25rem;
    }
    
    .alert-symbol {
        font-size: 0.85rem;
        font-weight: 500;
        display: flex;
        align-items: center;
        gap: 0.25rem;
        color: var(--text-primary);
    }
    
    .strike-price {
        font-size: 0.8rem;
        color: var(--text-secondary);
    }
    
        .alert-action {
        font-size: 0.75rem;
        font-weight: 600;
        padding: 0.2rem 0.4rem;
        border-radius: 4px;
    }
    
    .action-buy {
        background-color: rgba(38, 166, 154, 0.1);
        color: var(--success);
    }
    
    .action-sell {
        background-color: rgba(239, 83, 80, 0.1);
        color: var(--danger);
    }
    
    @keyframes slide-in {
        from {
            transform: translateX(-10px);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
</style>
