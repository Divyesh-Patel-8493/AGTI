<script>
    import { onMount, onDestroy } from 'svelte';
    import { fade, fly } from 'svelte/transition';
    import { portfolioStore } from '../../stores/portfolioStore.js';
    
    // Local state
    let showDetails = false;
    let isUpdating = false;
    let lastUpdateTime = '';
    
    // Format currency in Indian format
    const formatCurrency = (value) => {
        if (typeof value !== 'number') return '₹0.00';
        
        return new Intl.NumberFormat('en-IN', { 
            style: 'currency', 
            currency: 'INR', 
            minimumFractionDigits: 2, 
            maximumFractionDigits: 2 
        }).format(value);
    };
    
    // Format percentage
    const formatPercent = (value) => {
        if (typeof value !== 'number') return '0.00%';
        return `${value >= 0 ? '+' : ''}${value.toFixed(2)}%`;
    };
    
    // Update time display
    const updateTime = () => {
        const now = new Date();
        lastUpdateTime = now.toLocaleTimeString('en-IN');
        isUpdating = true;
        setTimeout(() => { isUpdating = false }, 1000);
    };
    
    // Set up auto refresh
    let refreshInterval;
    
    onMount(() => {
        // Initial update
        updateTime();
        
        // Set up auto refresh every minute
        refreshInterval = setInterval(() => {
            portfolioStore.refreshPortfolio();
            updateTime();
        }, 60 * 1000);
    });
    
    onDestroy(() => {
        clearInterval(refreshInterval);
    });
    
    // Subscribe to portfolio store
    $: portfolio = $portfolioStore;
</script>

<div class="portfolio-summary" on:click={() => showDetails = !showDetails}>
    <div class="portfolio-header">
        <h2>Portfolio Summary</h2>
        <div class="update-status">
            <span class="update-time">Last updated: {lastUpdateTime}</span>
            <span class="update-indicator {isUpdating ? 'active' : ''}"></span>
        </div>
    </div>
    
    <div class="portfolio-value">
        <div class="amount">
            {formatCurrency(portfolio.currentValue)}
            <span class={portfolio.dayPL >= 0 ? 'positive' : 'negative'}>
                {formatCurrency(portfolio.dayPL)} ({formatPercent(portfolio.dayPLPercent)})
            </span>
        </div>
    </div>
    
    {#if showDetails}
        <div class="portfolio-details" transition:fly={{ y: -20, duration: 300 }}>
            <div class="detail-row">
                <div class="detail-item">
                    <span>Invested</span>
                    <span class="detail-value">{formatCurrency(portfolio.investedAmount)}</span>
                </div>
                <div class="detail-item">
                    <span>Available</span>
                    <span class="detail-value">{formatCurrency(portfolio.availableCash)}</span>
                </div>
            </div>
            
            <div class="detail-row">
                <div class="detail-item">
                    <span>Total P/L</span>
                    <span class="detail-value {portfolio.totalPL >= 0 ? 'positive' : 'negative'}">
                        {formatCurrency(portfolio.totalPL)} ({formatPercent(portfolio.totalPLPercent)})
                    </span>
                </div>
                <div class="detail-item">
                    <span>Today's Trades</span>
                    <span class="detail-value">{portfolio.todayTrades}</span>
                </div>
            </div>
            
            <div class="risk-meter">
                <div class="risk-label">Risk Utilization</div>
                <div class="risk-bar">
                    <div 
                        class="risk-fill"
                        style="width: {Math.min(100, portfolio.riskUtilizationPercent)}%"
                        class:warning={portfolio.riskUtilizationPercent > 70}
                        class:danger={portfolio.riskUtilizationPercent > 90}
                    ></div>
                </div>
                <div class="risk-value">{portfolio.riskUtilizationPercent.toFixed(0)}%</div>
            </div>
        </div>
    {/if}
</div>

<style>
    .portfolio-summary {
        background: var(--bg-card);
        border-radius: 12px;
        padding: 1.5rem;
        box-shadow: var(--shadow-sm);
        cursor: pointer;
        transition: all 0.3s ease;
    }
    
    .portfolio-summary:hover {
        transform: translateY(-2px);
        box-shadow: var(--shadow-md);
    }
    
    .portfolio-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 0.5rem;
    }
    
    .portfolio-header h2 {
        margin: 0;
        font-size: 1.1rem;
        font-weight: 600;
        color: var(--text-secondary);
    }
    
    .update-status {
        display: flex;
        align-items: center;
        gap: 0.5rem;
        font-size: 0.8rem;
        color: var(--text-muted);
    }
    
    .update-indicator {
        width: 8px;
        height: 8px;
        border-radius: 50%;
        background-color: var(--text-muted);
    }
    
    .update-indicator.active {
        background-color: var(--success);
        animation: pulse 2s infinite;
    }
    
    .portfolio-value {
        margin: 1rem 0;
    }
    
    .amount {
        font-size: 2rem;
        font-weight: 700;
        margin-bottom: 0.25rem;
        color: var(--text-primary);
    }
    
    .amount span {
        display: block;
        font-size: 1.1rem;
        margin-top: 0.5rem;
        font-weight: 600;
    }
    
    .positive {
        color: var(--success);
    }
    
    .negative {
        color: var(--danger);
    }
    
    .portfolio-details {
        margin-top: 1.5rem;
        padding-top: 1rem;
        border-top: 1px solid var(--border-color);
    }
    
        .detail-row {
        display: flex;
        justify-content: space-between;
        margin-bottom: 1rem;
    }
    
    .detail-item {
        flex: 1;
        display: flex;
        flex-direction: column;
        gap: 0.25rem;
    }
    
    .detail-item span:first-child {
        font-size: 0.9rem;
        color: var(--text-secondary);
    }
    
    .detail-value {
        font-size: 1.1rem;
        font-weight: 600;
    }
    
    .risk-meter {
        margin-top: 1rem;
    }
    
    .risk-label {
        font-size: 0.9rem;
        color: var(--text-secondary);
        margin-bottom: 0.25rem;
    }
    
    .risk-bar {
        height: 8px;
        background-color: var(--bg-light);
        border-radius: 4px;
        overflow: hidden;
        margin-bottom: 0.25rem;
    }
    
    .risk-fill {
        height: 100%;
        background-color: var(--primary);
        border-radius: 4px;
        transition: width 0.5s ease;
    }
    
    .risk-fill.warning {
        background-color: var(--warning);
    }
    
    .risk-fill.danger {
        background-color: var(--danger);
    }
    
    .risk-value {
        text-align: right;
        font-size: 0.8rem;
        color: var(--text-muted);
    }
    
    @keyframes pulse {
        0% {
            opacity: 1;
        }
        50% {
            opacity: 0.5;
        }
        100% {
            opacity: 1;
        }
    }
</style>
