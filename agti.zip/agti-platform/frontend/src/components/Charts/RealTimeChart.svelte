<script>
    import { onMount, onDestroy } from 'svelte';
    import { createChart, CrosshairMode } from 'lightweight-charts';
    import { marketStore } from '../../stores/marketStore.js';
    
    // Chart container reference
    let chartContainer;
    let chart;
    let candleSeries;
    let volumeSeries;
    
    // Chart options
    export let symbol = 'NIFTY50';
    export let timeframe = '15m';
    export let height = 500;
    export let theme = 'dark';
    
    // Watch for store changes
    $: marketData = $marketStore.getSymbolData(symbol);
    $: if (chart && marketData && marketData.lastCandle) {
        updateChart(marketData.lastCandle);
    }
    
    onMount(() => {
        initializeChart();
        loadHistoricalData();
        
        // Subscribe to real-time updates
        marketStore.subscribeToSymbol(symbol, timeframe);
    });
    
    onDestroy(() => {
        if (chart) {
            chart.remove();
        }
        // Unsubscribe to prevent memory leaks
        marketStore.unsubscribeFromSymbol(symbol);
    });
    
    function initializeChart() {
        const chartOptions = {
            width: chartContainer.clientWidth,
            height: height,
            layout: {
                backgroundColor: theme === 'dark' ? '#1a1a2e' : '#ffffff',
                textColor: theme === 'dark' ? '#d1d4dc' : '#191919',
                fontSize: 12,
            },
            grid: {
                vertLines: {
                    color: theme === 'dark' ? '#2B2B43' : '#e6e6e6',
                    style: 1,
                    visible: true,
                },
                horzLines: {
                    color: theme === 'dark' ? '#2B2B43' : '#e6e6e6',
                    style: 1,
                    visible: true,
                },
            },
            crosshair: {
                mode: CrosshairMode.Normal,
            },
            rightPriceScale: {
                borderColor: theme === 'dark' ? '#2B2B43' : '#e6e6e6',
            },
            timeScale: {
                borderColor: theme === 'dark' ? '#2B2B43' : '#e6e6e6',
                timeVisible: true,
                secondsVisible: false,
            },
        };
        
        chart = createChart(chartContainer, chartOptions);
        
        // Handle resize
        const resizeObserver = new ResizeObserver(entries => {
            if (entries.length === 0 || entries[0].target !== chartContainer) return;
            
            const newRect = entries[0].contentRect;
            chart.applyOptions({ width: newRect.width });
        });
        
        resizeObserver.observe(chartContainer);
        
        // Add candle series
        candleSeries = chart.addCandlestickSeries({
            upColor: '#26a69a',
            downColor: '#ef5350',
            borderVisible: false,
            wickUpColor: '#26a69a',
            wickDownColor: '#ef5350',
        });
        
        // Add volume series
        volumeSeries = chart.addHistogramSeries({
            color: '#26a69a',
            priceFormat: {
                type: 'volume',
            },
            priceScaleId: '',
        });
        
        volumeSeries.priceScale().applyOptions({
            scaleMargins: {
                top: 0.8,
                bottom: 0,
            },
        });
    }
    
    async function loadHistoricalData() {
        try {
            await marketStore.loadHistoricalData(symbol, timeframe);
            
            const data = $marketStore.getSymbolData(symbol);
            
            if (data && data.candles && data.candles.length > 0) {
                candleSeries.setData(data.candles);
                volumeSeries.setData(data.volumes);
                
                // Adjust time scale to show most recent candles
                chart.timeScale().fitContent();
            }
        } catch (error) {
            console.error('Error loading historical data:', error);
        }
    }
    
    function updateChart(candle) {
        if (!candle || !candleSeries) return;
        
        // Update last candle or add new one
        candleSeries.update(candle);
        
        // Update volume
        if (volumeSeries) {
            volumeSeries.update({
                time: candle.time,
                value: candle.volume,
                color: candle.close >= candle.open ? '#26a69a' : '#ef5350'
            });
        }
    }
    
    function handleTimeframeChange(event) {
        timeframe = event.target.value;
        
        // Unsubscribe from old timeframe
        marketStore.unsubscribeFromSymbol(symbol);
        
        // Re-initialize with new timeframe
        if (chart) {
            chart.remove();
            initializeChart();
        }
        
        // Load data for new timeframe
        loadHistoricalData();
        
        // Subscribe to new timeframe
        marketStore.subscribeToSymbol(symbol, timeframe);
    }
</script>

<div class="chart-wrapper">
    <div class="chart-header">
        <div class="symbol-info">
            <h3>{symbol}</h3>
            <div class="price-info" class:price-up={marketData?.priceChange > 0} class:price-down={marketData?.priceChange < 0}>
                <span class="current-price">{marketData?.lastPrice?.toLocaleString('en-IN', { maximumFractionDigits: 2 }) || '0.00'}</span>
                <span class="price-change">
                    {marketData?.priceChange > 0 ? '+' : ''}{marketData?.priceChange?.toLocaleString('en-IN', { maximumFractionDigits: 2 }) || '0.00'} 
                    ({marketData?.priceChangePercent > 0 ? '+' : ''}{marketData?.priceChangePercent?.toFixed(2) || '0.00'}%)
                </span>
            </div>
        </div>
        
        <div class="chart-controls">
            <select bind:value={timeframe} on:change={handleTimeframeChange}>
                <option value="1m">1 Minute</option>
                <option value="5m">5 Minutes</option>
                <option value="15m">15 Minutes</option>
                <option value="30m">30 Minutes</option>
                <option value="1h">1 Hour</option>
                <option value="1d">Daily</option>
            </select>
        </div>
    </div>
    
    <div class="chart-container" bind:this={chartContainer}></div>
</div>

<style>
    .chart-wrapper {
        width: 100%;
        border-radius: 12px;
        background: var(--bg-card);
        padding: 1rem;
        box-shadow: var(--shadow-sm);
    }
    
    .chart-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 1rem;
    }
    
    .symbol-info h3 {
        margin: 0;
        font-size: 1.2rem;
        font-weight: 600;
    }
    
    .price-info {
        display: flex;
        align-items: center;
        gap: 0.5rem;
        margin-top: 0.25rem;
    }
    
    .current-price {
        font-size: 1.1rem;
        font-weight: 600;
    }
    
    .price-change {
        font-size: 0.9rem;
        border-radius: 4px;
        padding: 0.1rem 0.5rem;
    }
    
    .price-up .price-change {
        background-color: rgba(38, 166, 154, 0.1);
        color: var(--success);
    }
    
    .price-down .price-change {
        background-color: rgba(239, 83, 80, 0.1);
        color: var(--danger);
    }
    
    .chart-controls {
        display: flex;
        gap: 0.5rem;
    }
    
    .chart-controls select {
        background: var(--bg-input);
        border: 1px solid var(--border-color);
        border-radius: 4px;
        padding: 0.25rem 0.5rem;
        font-size: 0.9rem;
        color: var(--text-primary);
    }
    
    .chart-container {
        width: 100%;
        height: 100%;
        min-height: 200px;
    }
</style>
