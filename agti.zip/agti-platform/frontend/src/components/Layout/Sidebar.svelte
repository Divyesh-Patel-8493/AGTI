<script>
  import { Link, navigate } from 'svelte-routing';
  import { alertStore } from '../../stores/alertStore.js';
  
  export let sidebarCollapsed = false;
  
  const menuItems = [
    {
      path: '/',
      label: 'Dashboard',
      icon: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="9"></rect><rect x="14" y="3" width="7" height="5"></rect><rect x="14" y="12" width="7" height="9"></rect><rect x="3" y="16" width="7" height="5"></rect></svg>'
    },
    {
      path: '/options',
      label: 'Options',
      icon: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 9H4.5a2.5 2.5 0 0 1 0-5H6"></path><path d="M18 9h1.5a2.5 2.5 0 0 0 0-5H18"></path><path d="M4 22h16"></path><path d="M10 14.66V17c0 .55-.47.98-.97 1.21C7.85 18.75 7 20.24 7 22"></path><path d="M14 14.66V17c0 .55.47.98.97 1.21C16.15 18.75 17 20.24 17 22"></path><path d="M18 2H6v7a6 6 0 0 0 12 0V2Z"></path></svg>'
    },
    {
      path: '/alerts',
      label: 'Alerts',
      icon: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path><path d="M13.73 21a2 2 0 0 1-3.46 0"></path></svg>',
      badge: $alertStore.unreadCount
    },
    {
      path: '/strategies',
      label: 'Strategies',
      icon: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"></polyline></svg>'
    },
    {
      path: '/settings',
      label: 'Settings',
      icon: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path></svg>'
    }
  ];
  
  let currentRoute = '/';
  
  // Update the active route
  function updateRoute() {
    currentRoute = window.location.pathname;
  }
</script>

<svelte:window on:popstate={updateRoute} />

<aside class="sidebar {sidebarCollapsed ? 'collapsed' : ''}">
  <div class="logo-container">
    {#if !sidebarCollapsed}
      <div class="logo">
        <span class="logo-text">AGTI</span>
        <span class="logo-version">v1.0</span>
      </div>
    {:else}
      <div class="logo-small">A</div>
    {/if}
  </div>
  
  <nav class="nav-menu">
    <ul>
      {#each menuItems as item}
        <li class:active={currentRoute === item.path}>
          <Link to={item.path} on:click={updateRoute}>
            <div class="menu-icon" title={sidebarCollapsed ? item.label : null}>
              {@html item.icon}
            </div>
            {#if !sidebarCollapsed}
              <span class="menu-label">{item.label}</span>
              {#if item.badge && item.badge > 0}
                <span class="badge">{item.badge > 99 ? '99+' : item.badge}</span>
              {/if}
            {:else if item.badge && item.badge > 0}
              <span class="badge badge-small">{item.badge > 9 ? '9+' : item.badge}</span>
            {/if}
          </Link>
        </li>
      {/each}
    </ul>
  </nav>
  
  <div class="sidebar-footer">
    {#if !sidebarCollapsed}
      <div class="version-info">
        <span>AGTI Platform</span>
        <span class="version">v1.0</span>
      </div>
    {:else}
      <div class="version-info-small">v1</div>
    {/if}
  </div>
</aside>

<style>
  .sidebar {
    width: 240px;
    height: 100vh;
    background-color: var(--bg-secondary);
    color: var(--text-primary);
    display: flex;
    flex-direction: column;
    border-right: 1px solid var(--border-color);
    transition: width 0.3s ease;
    z-index: 100;
  }
  
  .sidebar.collapsed {
    width: 64px;
  }
  
  .logo-container {
    padding: 1.5rem;
    display: flex;
    align-items: center;
    justify-content: center;
    height: 60px;
  }
  
  .logo {
    display: flex;
    flex-direction: column;
    align-items: center;
  }
  
  .logo-text {
    font-size: 1.5rem;
    font-weight: 700;
    letter-spacing: 1px;
    background: linear-gradient(90deg, var(--primary), var(--info));
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
  }
  
  .logo-version {
    font-size: 0.7rem;
    color: var(--text-muted);
    margin-top: -5px;
  }
  
  .logo-small {
    font-size: 1.5rem;
    font-weight: 700;
    background: linear-gradient(90deg, var(--primary), var(--info));
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
  }
  
  .nav-menu {
    flex: 1;
    overflow-y: auto;
    padding: 1rem 0;
  }
  
  .nav-menu ul {
    list-style: none;
    padding: 0;
    margin: 0;
  }
  
  .nav-menu li {
    margin-bottom: 0.5rem;
  }
  
  .nav-menu li a {
    display: flex;
    align-items: center;
    padding: 0.75rem 1.5rem;
    text-decoration: none;
    color: var(--text-secondary);
    transition: all 0.2s ease;
    position: relative;
  }
  
  .nav-menu li a:hover {
    color: var(--text-primary);
    background-color: var(--bg-hover);
  }
  
  .nav-menu li.active a {
    color: var(--primary);
    background-color: var(--bg-active);
    font-weight: 500;
  }
  
  .menu-icon {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 24px;
    height: 24px;
    margin-right: 12px;
  }
  
  .collapsed .menu-icon {
    margin-right: 0;
  }
  
  .menu-label {
    flex: 1;
  }
  
  .badge {
    background-color: var(--danger);
    color: white;
    font-size: 0.7rem;
    font-weight: 600;
    padding: 0.15rem 0.5rem;
    border-radius: 10px;
    min-width: 20px;
    text-align: center;
  }
  
  .badge-small {
    position: absolute;
    top: 8px;
    right: 8px;
    padding: 0.1rem 0.3rem;
    min-width: 16px;
    font-size: 0.65rem;
  }
  
  .sidebar-footer {
    padding: 1rem 1.5rem;
    border-top: 1px solid var(--border-color);
  }
  
  .version-info {
    display: flex;
    justify-content: space-between;
    font-size: 0.8rem;
    color: var(--text-muted);
  }
  
  .version-info-small {
    text-align: center;
    font-size: 0.7rem;
    color: var(--text-muted);
  }
</style>
