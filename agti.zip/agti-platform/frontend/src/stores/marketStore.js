import { writable, derived } from 'svelte/store';
import { browser } from '$app/environment';

// Initial state
const initialState = {
    symbols: {},
    subscriptions: {},
    lastUpdate: new Date().toISOString()
};

// Create the writable store
function createMarketStore() {
    const { subscribe, set, update } = writable(initialState);
    
    // WebSocket connection
    let socket = null;
    
    // Connect to WebSocket
    function connectWebSocket() {
        if (!browser) return null;
        
        try {
            const wsUrl = import.meta.env.VITE_WS_URL || 'ws://localhost:8000/ws/market';
            const ws = new WebSocket(wsUrl);
            
            ws.onopen = () => {
                console.log('WebSocket connected for market data');
                
                // Resubscribe to existing symbols
                update(state => {
                    Object.keys(state.subscriptions).forEach(symbol => {
                        const subscription = state.subscriptions[symbol];
                        ws.send(JSON.stringify({
                            action: 'subscribe',
                            symbol,
                            timeframe: subscription.timeframe
                        }));
                    });
                    return state;
                });
            };
            
            ws.onmessage = (event) => {
                const data = JSON.parse(event.data);
                
                // Handle different message types
                if (data.type === 'tick') {
                    handleTickData(data);
                } else if (data.type === 'candle') {
                    handleCandleData(data);
                }
            };
            
            ws.onerror = (error) => {
                console.error('WebSocket error:', error);
                setTimeout(connectWebSocket, 5000); // Reconnect after 5 seconds
            };
            
            ws.onclose = () => {
                console.log('WebSocket closed, reconnecting...');
                setTimeout(connectWebSocket, 5000); // Reconnect after 5 seconds
            };
            
            return ws;
        } catch (error) {
            console.error('WebSocket connection error:', error);
            return null;
        }
    }
    
    // Handle tick data updates
    function handleTickData(data) {
        update(state => {
            const { symbol, price, change, changePercent, volume, timestamp } = data;
            
            // Get existing symbol data or create new entry
            const existingData = state.symbols[symbol] || { candles: [], volumes: [] };
            
            // Update symbol data
            return {
                ...state,
                symbols: {
                    ...state.symbols,
                    [symbol]: {
                        ...existingData,
                        lastPrice: price,
                        priceChange: change,
                        priceChangePercent: changePercent,
                        lastVolume: volume,
                        lastUpdate: timestamp
                    }
                },
                lastUpdate: new Date().toISOString()
            };
        });
    }
    
    // Handle candle data updates
    function handleCandleData(data) {
        update(state => {
            const { symbol, timeframe, candle } = data;
            
            // Get existing symbol data or create new entry
            const existingData = state.symbols[symbol] || { 
                candles: [], 
                volumes: [],
                lastPrice: 0,
                priceChange: 0,
                priceChangePercent: 0 
            };
            
            // Check if we need to update an existing candle or add a new one
            let candles = [...existingData.candles];
            let volumes = [...existingData.volumes];
            
            const lastCandleIndex = candles.findIndex(c => c.time === candle.time);
            
            if (lastCandleIndex >= 0) {
                // Update existing candle
                candles[lastCandleIndex] = candle;
                
                // Update volume
                volumes[lastCandleIndex] = {
                    time: candle.time,
                    value: candle.volume,
                    color: candle.close >= candle.open ? '#26a69a' : '#ef5350'
                };
            } else {
                // Add new candle
                candles.push(candle);
                
                // Add volume
                volumes.push({
                    time: candle.time,
                    value: candle.volume,
                    color: candle.close >= candle.open ? '#26a69a' : '#ef5350'
                });
            }
            
            // Update lastPrice and price change from the latest candle
            const latestCandle = candle;
            const previousCandle = candles.length > 1 ? candles[candles.length - 2] : null;
            
            const lastPrice = latestCandle.close;
            const priceChange = previousCandle ? latestCandle.close - previousCandle.close : 0;
            const priceChangePercent = previousCandle ? (priceChange / previousCandle.close) * 100 : 0;
            
            return {
                ...state,
                symbols: {
                    ...state.symbols,
                    [symbol]: {
                        ...existingData,
                        candles,
                        volumes,
                        lastCandle: candle,
                        lastPrice,
                        priceChange,
                        priceChangePercent,
                        timeframe
                    }
                },
                lastUpdate: new Date().toISOString()
            };
        });
    }
    
    // Initialize store
    if (browser) {
        socket = connectWebSocket();
    }
    
    return {
        subscribe,
        
        // Load historical data for a symbol
        loadHistoricalData: async (symbol, timeframe) => {
            try {
                const response = await fetch(`/api/market/history?symbol=${symbol}&timeframe=${timeframe}`);
                if (!response.ok) throw new Error('Failed to fetch historical data');
                
                const data = await response.json();
                
                update(state => {
                    // Format candles for TradingView
                    const candles = data.candles.map(c => ({
                        time: c.time,
                        open: c.open,
                        high: c.high,
                        low: c.low,
                        close: c.close,
                        volume: c.volume
                    }));
                    
                    // Format volumes
                    const volumes = data.candles.map(c => ({
                        time: c.time,
                        value: c.volume,
                        color: c.close >= c.open ? '#26a69a' : '#ef5350'
                    }));
                    
                    // Calculate price change from last two candles
                    const lastCandle = candles[candles.length - 1];
                    const prevCandle = candles.length > 1 ? candles[candles.length - 2] : null;
                    
                    const lastPrice = lastCandle?.close || 0;
                    const priceChange = prevCandle ? lastCandle.close - prevCandle.close : 0;
                    const priceChangePercent = prevCandle ? (priceChange / prevCandle.close) * 100 : 0;
                    
                    return {
                        ...state,
                        symbols: {
                            ...state.symbols,
                            [symbol]: {
                                candles,
                                volumes,
                                lastCandle,
                                lastPrice,
                                priceChange,
                                priceChangePercent,
                                timeframe
                            }
                        }
                    };
                });
                
                return true;
            } catch (error) {
                console.error('Error loading historical data:', error);
                
                // In development, generate mock data
                if (process.env.NODE_ENV === 'development') {
                    generateMockData(symbol, timeframe, update);
                }
                
                return false;
            }
        },
        
        // Subscribe to real-time updates for a symbol
        subscribeToSymbol: (symbol, timeframe) => {
            if (!browser) return;
            
            update(state => {
                // Check if already subscribed to this symbol and timeframe
                if (
                    state.subscriptions[symbol] &&
                    state.subscriptions[symbol].timeframe === timeframe
                ) {
                    return state;
                }
                
                // Add to subscriptions
                const newState = {
                    ...state,
                    subscriptions: {
                        ...state.subscriptions,
                        [symbol]: { timeframe, timestamp: new Date().toISOString() }
                    }
                };
                
                // Send subscribe message to WebSocket
                if (socket && socket.readyState === WebSocket.OPEN) {
                    socket.send(JSON.stringify({
                        action: 'subscribe',
                        symbol,
                        timeframe
                    }));
                }
                
                return newState;
            });
        },
        
        // Unsubscribe from real-time updates for a symbol
        unsubscribeFromSymbol: (symbol) => {
            if (!browser) return;
            
            update(state => {
                // Check if subscribed to this symbol
                if (!state.subscriptions[symbol]) {
                    return state;
                }
                
                // Create a new subscriptions object without this symbol
                const { [symbol]: removed, ...restSubscriptions } = state.subscriptions;
                
                // Send unsubscribe message to WebSocket
                if (socket && socket.readyState === WebSocket.OPEN) {
                    socket.send(JSON.stringify({
                        action: 'unsubscribe',
                        symbol
                    }));
                }
                
                return {
                    ...state,
                    subscriptions: restSubscriptions
                };
            });
        },
        
        // Get data for a specific symbol
        getSymbolData: (symbol) => {
            let result = null;
            
            subscribe(state => {
                result = state.symbols[symbol] || null;
            })();
            
            return result;
        },
        
        // Clean up resources
        cleanup: () => {
            if (socket) {
                socket.close();
                socket = null;
            }
        }
    };
}

// Generate mock data for development
function generateMockData(symbol, timeframe, update) {
    const now = new Date();
    const candles = [];
    const volumes = [];
    
    // Generate 100 candles
    const basePrice = symbol === 'NIFTY50' ? 18000 : 40000;
    let currentPrice = basePrice;
    
    for (let i = 0; i < 100; i++) {
        // Random price movement
        const change = (Math.random() - 0.5) * basePrice * 0.01;
        const open = currentPrice;
        const close = open + change;
        const high = Math.max(open, close) + Math.random() * basePrice * 0.005;
        const low = Math.min(open, close) - Math.random() * basePrice * 0.005;
        
        // Calculate candle time
        let candleTime;
        if (timeframe === '1d') {
            candleTime = new Date(now);
            candleTime.setDate(candleTime.getDate() - (100 - i));
            candleTime.setHours(0, 0, 0, 0);
        } else if (timeframe === '1h') {
            candleTime = new Date(now);
            candleTime.setHours(candleTime.getHours() - (100 - i));
            candleTime.setMinutes(0, 0, 0);
        } else {
            // Default to 15m
            candleTime = new Date(now);
            candleTime.setMinutes(candleTime.getMinutes() - (100 - i) * 15);
            candleTime.setSeconds(0, 0);
        }
        
        // Add candle
        candles.push({
            time: Math.floor(candleTime.getTime() / 1000),
            open,
            high,
            low,
            close,
            volume: Math.floor(Math.random() * 1000000) + 500000
        });
        
        // Add volume
        volumes.push({
            time: Math.floor(candleTime.getTime() / 1000),
            value: candles[i].volume,
            color: close >= open ? '#26a69a' : '#ef5350'
        });
        
        // Update price for next candle
        currentPrice = close;
    }
    
    const lastCandle = candles[candles.length - 1];
    const prevCandle = candles[candles.length - 2];
    
    update(state => {
        return {
            ...state,
            symbols: {
                ...state.symbols,
                [symbol]: {
                    candles,
                    volumes,
                    lastCandle,
                    lastPrice: lastCandle.close,
                    priceChange: lastCandle.close - prevCandle.close,
                    priceChangePercent: ((lastCandle.close - prevCandle.close) / prevCandle.close) * 100,
                    timeframe
                }
            }
        };
    });
}

// Export the store
export const marketStore = createMarketStore();

// Derived store for market indices
export const marketIndices = derived(
    marketStore,
    $market => {
        const indices = {};
        
        // Extract indices (NIFTY50, BANKNIFTY, etc.)
        Object.keys($market.symbols).forEach(symbol => {
            if (symbol.includes('NIFTY') || symbol === 'SENSEX') {
                indices[symbol] = {
                    lastPrice: $market.symbols[symbol].lastPrice,
                    priceChange: $market.symbols[symbol].priceChange,
                    priceChangePercent: $market.symbols[symbol].priceChangePercent
                };
            }
        });
        
        return indices;
    }
);
