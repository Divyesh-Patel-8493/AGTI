import { writable } from 'svelte/store';
import { browser } from '$app/environment';

// Initial state
const initialState = {
    alerts: [],
    unreadCount: 0,
    lastUpdate: new Date().toISOString()
};

// Create the writable store
function createAlertStore() {
    const { subscribe, set, update } = writable(initialState);
    
    let pollingInterval = null;
    
    return {
        subscribe,
        
        // Fetch alerts from the server
        fetchAlerts: async () => {
            try {
                const response = await fetch('/api/alerts');
                if (!response.ok) throw new Error('Failed to fetch alerts');
                
                const data = await response.json();
                
                update(state => {
                    // Calculate unread count (new alerts compared to current state)
                    const existingIds = new Set(state.alerts.map(a => a.id));
                    const newAlerts = data.filter(a => !existingIds.has(a.id));
                    
                    return {
                        alerts: data,
                        unreadCount: state.unreadCount + newAlerts.length,
                        lastUpdate: new Date().toISOString()
                    };
                });
            } catch (error) {
                console.error('Error fetching alerts:', error);
                
                // In development, generate mock alerts
                if (browser && process.env.NODE_ENV === 'development') {
                    generateMockAlerts(update);
                }
            }
        },
        
        // Start polling for new alerts
        startPolling: (interval = 30000) => {
            if (pollingInterval) clearInterval(pollingInterval);
            
            // Initial fetch
            createAlertStore().fetchAlerts();
            
            // Set up polling
            pollingInterval = setInterval(() => {
                createAlertStore().fetchAlerts();
            }, interval);
        },
        
        // Stop polling
        stopPolling: () => {
            if (pollingInterval) {
                clearInterval(pollingInterval);
                pollingInterval = null;
            }
        },
        
        // Mark alerts as read
        markAsRead: () => {
            update(state => ({
                ...state,
                unreadCount: 0
            }));
        },
        
        // Add a new alert (local only)
        addAlert: (alert) => {
            update(state => {
                const newAlert = {
                    id: `local-${Date.now()}`,
                    timestamp: new Date().toISOString(),
                    ...alert
                };
                
                return {
                    ...state,
                    alerts: [newAlert, ...state.alerts],
                    unreadCount: state.unreadCount + 1
                };
            });
        },
        
        // Remove an alert
        removeAlert: (id) => {
            update(state => ({
                ...state,
                alerts: state.alerts.filter(a => a.id !== id)
            }));
        },
        
        // Clear all alerts
        clearAlerts: () => {
            update(state => ({
                ...state,
                alerts: [],
                unreadCount: 0
            }));
        }
    };
}

// Generate mock alerts for development
function generateMockAlerts(update) {
    const alertTypes = ['options', 'market', 'news'];
    const priorities = ['normal', 'high', 'critical'];
    const symbols = ['NIFTY50', 'BANKNIFTY', 'RELIANCE', 'HDFCBANK', 'TCS'];
    
    // Generate 1-3 mock alerts
    const count = Math.floor(Math.random() * 3) + 1;
    const mockAlerts = [];
    
    for (let i = 0; i < count; i++) {
        const type = alertTypes[Math.floor(Math.random() * alertTypes.length)];
        const priority = priorities[Math.floor(Math.random() * priorities.length)];
        const symbol = symbols[Math.floor(Math.random() * symbols.length)];
        
        let title, message, title_gujarati, message_gujarati;
        
        if (type === 'options') {
            title = `Options Alert: ${symbol}`;
            message = `Implied Volatility for ${symbol} options has dropped significantly, potential buying opportunity.`;
            title_gujarati = `ઓપ્શન્સ એલર્ટ: ${symbol}`;
            message_gujarati = `${symbol} વિકલ્પો માટે આભાસી અસ્થિરતા નોંધપાત્ર રીતે ઘટી છે, સંભવિત ખરીદી તક.`;
        } else if (type === 'market') {
            title = `Market Movement: ${symbol}`;
            message = `${symbol} has moved ${Math.random() > 0.5 ? 'up' : 'down'} by ${(Math.random() * 2 + 1).toFixed(2)}% in the last 15 minutes.`;
            title_gujarati = `માર્કેટ મૂવમેન્ટ: ${symbol}`;
            message_gujarati = `${symbol} છેલ્લા 15 મિનિટમાં ${Math.random() > 0.5 ? 'વધ્યું' : 'ઘટ્યું'} ${(Math.random() * 2 + 1).toFixed(2)}% દ્વારા.`;
        } else {
            title = `News Alert: ${symbol}`;
            message = `Breaking news affecting ${symbol}: ${Math.random() > 0.5 ? 'Positive' : 'Negative'} developments reported.`;
            title_gujarati = `સમાચાર એલર્ટ: ${symbol}`;
            message_gujarati = `${symbol} ને અસર કરતા તાજા સમાચાર: ${Math.random() > 0.5 ? 'સકારાત્મક' : 'નકારાત્મક'} વિકાસ નોંધાયા.`;
        }
        
        mockAlerts.push({
            id: `mock-${Date.now()}-${i}`,
            type,
            priority,
            title,
            message,
            title_gujarati,
            message_gujarati,
            symbol,
            timestamp: new Date().toISOString()
        });
    }
    
    update(state => {
        const existingIds = new Set(state.alerts.map(a => a.id));
        const newAlerts = mockAlerts.filter(a => !existingIds.has(a.id));
        
        return {
            alerts: [...newAlerts, ...state.alerts].slice(0, 20), // Keep only 20 most recent
            unreadCount: state.unreadCount + newAlerts.length,
            lastUpdate: new Date().toISOString()
        };
    });
}

// Export the store
export const alertStore = createAlertStore();
