import { writable, derived } from 'svelte/store';
import { browser } from '$app/environment';

// Initial state
const initialState = {
    currentValue: 5000, // Initial capital as per requirement (₹5,000)
    investedAmount: 0,
    availableCash: 5000,
    dayPL: 0,
    dayPLPercent: 0,
    totalPL: 0,
    totalPLPercent: 0,
    positions: [],
    todayTrades: 0,
    riskUtilizationPercent: 0,
    lastUpdate: new Date().toISOString()
};

// Create the writable store
function createPortfolioStore() {
    const { subscribe, set, update } = writable(initialState);
    
    return {
        subscribe,
        
        // Refresh portfolio data from the server
        refreshPortfolio: async () => {
            try {
                const response = await fetch('/api/portfolio');
                if (!response.ok) throw new Error('Failed to fetch portfolio data');
                
                const data = await response.json();
                update(state => ({
                    ...state,
                    ...data,
                    lastUpdate: new Date().toISOString()
                }));
            } catch (error) {
                console.error('Error refreshing portfolio:', error);
                // Fall back to simulated updates in development
                if (browser && process.env.NODE_ENV === 'development') {
                    simulatePortfolioUpdate(update);
                }
            }
        },
        
        // Update a specific position
        updatePosition: (symbol, changes) => {
            update(state => {
                const positions = state.positions.map(pos => {
                    if (pos.symbol === symbol) {
                        return { ...pos, ...changes };
                    }
                    return pos;
                });
                
                return {
                    ...state,
                    positions
                };
            });
        },
        
        // Add a new position
        addPosition: (position) => {
            update(state => {
                // Check if position already exists
                const existingIndex = state.positions.findIndex(p => p.symbol === position.symbol);
                
                if (existingIndex >= 0) {
                    // Update existing position
                    const positions = [...state.positions];
                    positions[existingIndex] = {
                        ...positions[existingIndex],
                        ...position,
                        quantity: positions[existingIndex].quantity + position.quantity
                    };
                    
                    return {
                        ...state,
                        positions,
                        todayTrades: state.todayTrades + 1
                    };
                } else {
                    // Add new position
                    return {
                        ...state,
                        positions: [...state.positions, position],
                        todayTrades: state.todayTrades + 1
                    };
                }
            });
        },
        
        // Close a position
        closePosition: (symbol) => {
            update(state => {
                const positions = state.positions.filter(pos => pos.symbol !== symbol);
                
                return {
                    ...state,
                    positions,
                    todayTrades: state.todayTrades + 1
                };
            });
        },
        
        // Reset portfolio to initial state
        reset: () => {
            set(initialState);
        }
    };
}

// Helper function to simulate portfolio updates in development
function simulatePortfolioUpdate(update) {
    // Random price movements
    const priceChange = (Math.random() - 0.5) * 200; // ±100 rupees
    
    update(state => {
        const newTotal = state.currentValue + priceChange;
        const dayPLPercent = (priceChange / state.currentValue) * 100;
        
        // Update positions with random movements
        const positions = state.positions.map(pos => {
            const posChange = (Math.random() - 0.45) * pos.currentValue * 0.02; // Biased slightly positive
            return {
                ...pos,
                currentValue: pos.currentValue + posChange,
                unrealizedPL: pos.unrealizedPL + posChange
            };
        });
        
        return {
            ...state,
            currentValue: newTotal,
            dayPL: priceChange,
            dayPLPercent,
            positions,
            lastUpdate: new Date().toISOString()
        };
    });
}

// Export the store
export const portfolioStore = createPortfolioStore();

// Derived store for overall portfolio risk level
export const riskLevel = derived(
    portfolioStore,
    $portfolio => {
        // Calculate risk level based on portfolio metrics
        const { riskUtilizationPercent } = $portfolio;
        
        if (riskUtilizationPercent > 90) return 'high';
        if (riskUtilizationPercent > 70) return 'medium';
        return 'low';
    }
);
