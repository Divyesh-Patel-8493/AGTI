<script>
  import { onMount } from 'svelte';
  import { Router, Route } from 'svelte-routing';
  import { marketStore } from './stores/marketStore.js';
  import { portfolioStore } from './stores/portfolioStore.js';
  import { alertStore } from './stores/alertStore.js';
  
  // Components
  import Sidebar from './components/Layout/Sidebar.svelte';
  import TopBar from './components/Layout/TopBar.svelte';
  import Dashboard from './routes/Dashboard/index.svelte';
  import Options from './routes/Options/index.svelte';
  import Alerts from './routes/Alerts/index.svelte';
  import Strategies from './routes/Strategies/index.svelte';
  import Settings from './routes/Settings/index.svelte';
  
  // Theme state
  let darkMode = true;
  let currentTheme = 'dark';
  let sidebarCollapsed = false;
  
  // Check for system preference
  function checkSystemTheme() {
    if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
      darkMode = true;
      currentTheme = 'dark';
    } else {
      darkMode = false;
      currentTheme = 'light';
    }
    
    // Set theme on document
    document.documentElement.setAttribute('data-theme', currentTheme);
  }
  
  // Toggle theme
  function toggleTheme() {
    darkMode = !darkMode;
    currentTheme = darkMode ? 'dark' : 'light';
    localStorage.setItem('theme', currentTheme);
    document.documentElement.setAttribute('data-theme', currentTheme);
  }
  
  // Toggle sidebar
  function toggleSidebar() {
    sidebarCollapsed = !sidebarCollapsed;
    localStorage.setItem('sidebarCollapsed', JSON.stringify(sidebarCollapsed));
  }
  
  // Initialize app
  onMount(() => {
    // Load theme preference
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme) {
      darkMode = savedTheme === 'dark';
      currentTheme = savedTheme;
      document.documentElement.setAttribute('data-theme', currentTheme);
    } else {
      checkSystemTheme();
    }
    
    // Load sidebar state
    const savedSidebarState = localStorage.getItem('sidebarCollapsed');
    if (savedSidebarState !== null) {
      sidebarCollapsed = JSON.parse(savedSidebarState);
    }
    
    // Initialize stores
    marketStore.loadHistoricalData('NIFTY50', '15m');
    portfolioStore.refreshPortfolio();
    alertStore.startPolling();
    
    // Listen for system theme changes
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
    const handleChange = (e) => {
      if (!localStorage.getItem('theme')) {
        darkMode = e.matches;
        currentTheme = darkMode ? 'dark' : 'light';
        document.documentElement.setAttribute('data-theme', currentTheme);
      }
    };
    
    mediaQuery.addEventListener('change', handleChange);
    
    return () => {
      mediaQuery.removeEventListener('change', handleChange);
      alertStore.stopPolling();
      marketStore.cleanup();
    };
  });
</script>

<Router>
  <div class="app-container {sidebarCollapsed ? 'sidebar-collapsed' : ''}">
    <Sidebar {sidebarCollapsed} />
    
    <div class="main-content">
      <TopBar 
        {darkMode} 
        {sidebarCollapsed} 
        onToggleTheme={toggleTheme} 
        onToggleSidebar={toggleSidebar} 
      />
      
      <div class="content-area">
        <Route path="/" component={Dashboard} />
        <Route path="/options" component={Options} />
        <Route path="/alerts" component={Alerts} />
        <Route path="/strategies" component={Strategies} />
        <Route path="/settings" component={Settings} />
      </div>
    </div>
  </div>
</Router>

<style>
  :global(:root) {
    /* Light Theme Variables */
    --light-bg-primary: #f8f9fa;
    --light-bg-secondary: #ffffff;
    --light-bg-card: #ffffff;
    --light-bg-input: #f1f3f5;
    --light-bg-hover: #f1f3f5;
    --light-bg-active: #e9ecef;
    --light-bg-light: #f8f9fa;
    
    --light-text-primary: #212529;
    --light-text-secondary: #495057;
    --light-text-muted: #6c757d;
    
    --light-border-color: #dee2e6;
    --light-shadow-sm: 0 1px 3px rgba(0, 0, 0, 0.1);
    --light-shadow-md: 0 4px 6px rgba(0, 0, 0, 0.1);
    
    /* Dark Theme Variables */
    --dark-bg-primary: #121212;
    --dark-bg-secondary: #1e1e1e;
    --dark-bg-card: #252525;
    --dark-bg-input: #333333;
    --dark-bg-hover: #333333;
    --dark-bg-active: #404040;
    --dark-bg-light: #2a2a2a;
    
    --dark-text-primary: #e9ecef;
    --dark-text-secondary: #ced4da;
    --dark-text-muted: #adb5bd;
    
    --dark-border-color: #444444;
    --dark-shadow-sm: 0 1px 3px rgba(0, 0, 0, 0.3);
    --dark-shadow-md: 0 4px 6px rgba(0, 0, 0, 0.4);
    
    /* Common Colors */
    --primary: #007bff;
    --success: #28a745;
    --warning: #ffc107;
    --danger: #dc3545;
    --info: #17a2b8;
    
    /* Font Settings */
    --font-sans: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
    --font-mono: 'JetBrains Mono', 'Roboto Mono', 'Courier New', monospace;
  }
  
  :global([data-theme="light"]) {
    --bg-primary: var(--light-bg-primary);
    --bg-secondary: var(--light-bg-secondary);
    --bg-card: var(--light-bg-card);
    --bg-input: var(--light-bg-input);
    --bg-hover: var(--light-bg-hover);
    --bg-active: var(--light-bg-active);
    --bg-light: var(--light-bg-light);
    
    --text-primary: var(--light-text-primary);
    --text-secondary: var(--light-text-secondary);
    --text-muted: var(--light-text-muted);
    
    --border-color: var(--light-border-color);
    --shadow-sm: var(--light-shadow-sm);
    --shadow-md: var(--light-shadow-md);
    --shadow-xs: 0 1px 2px rgba(0, 0, 0, 0.05);
  }
  
  :global([data-theme="dark"]) {
    --bg-primary: var(--dark-bg-primary);
    --bg-secondary: var(--dark-bg-secondary);
    --bg-card: var(--dark-bg-card);
    --bg-input: var(--dark-bg-input);
    --bg-hover: var(--dark-bg-hover);
    --bg-active: var(--dark-bg-active);
    --bg-light: var(--dark-bg-light);
    
    --text-primary: var(--dark-text-primary);
    --text-secondary: var(--dark-text-secondary);
    --text-muted: var(--dark-text-muted);
    
    --border-color: var(--dark-border-color);
    --shadow-sm: var(--dark-shadow-sm);
    --shadow-md: var(--dark-shadow-md);
    --shadow-xs: 0 1px 2px rgba(0, 0, 0, 0.2);
  }
  
  :global(html, body) {
    margin: 0;
    padding: 0;
    font-family: var(--font-sans);
    background-color: var(--bg-primary);
    color: var(--text-primary);
    transition: background-color 0.3s ease, color 0.3s ease;
    height: 100%;
    overflow: hidden;
  }
  
  :global(*, *::before, *::after) {
    box-sizing: border-box;
  }
  
  :global(button, input, select, textarea) {
    font-family: inherit;
    font-size: inherit;
  }
  
  .app-container {
    display: flex;
    height: 100vh;
    width: 100vw;
    overflow: hidden;
  }
  
  .main-content {
    flex: 1;
    display: flex;
    flex-direction: column;
    overflow: hidden;
    transition: margin-left 0.3s ease;
  }
  
  .content-area {
    flex: 1;
    overflow-y: auto;
    padding: 1.5rem;
  }
  
  .sidebar-collapsed .main-content {
    margin-left: 64px;
  }
</style>
