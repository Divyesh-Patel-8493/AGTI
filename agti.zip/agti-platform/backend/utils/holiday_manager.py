"""
Holiday Manager for Indian markets
"""
from datetime import datetime, date, timedelta
import pandas as pd
from bs4 import BeautifulSoup
import requests
from typing import List, Dict, Optional
from loguru import logger
import os


class HolidayManager:
    """
    Manager for market holidays and trading hours
    Focused on Indian markets (NSE, BSE, MCX)
    """
    def __init__(self):
        self.cache_file = "data/cache/market_holidays.parquet"
        self.nse_holidays = self._load_holidays()
        self.exchange_timing = {
            'NSE': {'open': '09:15', 'close': '15:30'},
            'BSE': {'open': '09:15', 'close': '15:30'},
            'MCX': {'open': '09:00', 'close': '23:30'}  # Commodity market
        }
    
    def _load_holidays(self) -> pd.DataFrame:
        """
        Load holidays from cache or scrape from NSE website
        """
        # Check if cache exists and is current
        if os.path.exists(self.cache_file):
            try:
                holidays_df = pd.read_parquet(self.cache_file)
                
                # Check if data includes current year
                current_year = datetime.now().year
                if current_year in holidays_df['date'].dt.year.unique():
                    logger.info(f"Loaded {len(holidays_df)} holiday records from cache")
                    return holidays_df
            except Exception as e:
                logger.warning(f"Error loading holidays cache: {str(e)}")
        
        # If no cache or not current, scrape from NSE
        try:
            holidays_df = self._scrape_nse_holidays()
            
            # Cache the data
            os.makedirs(os.path.dirname(self.cache_file), exist_ok=True)
            holidays_df.to_parquet(self.cache_file)
            
            logger.info(f"Scraped and cached {len(holidays_df)} holiday records")
            return holidays_df
            
        except Exception as e:
            logger.error(f"Error scraping holidays: {str(e)}")
            
            # Fallback to hard-coded list of common holidays
            return self._get_fallback_holidays()
    
    def _scrape_nse_holidays(self) -> pd.DataFrame:
        """
        Scrape holiday calendar from NSE website
        """
        url = "https://www.nseindia.com/api/holiday-master?type=trading"
        headers = {
            "User-Agent": "Mozilla/5.0",
            "Accept-Language": "en-US,en;q=0.9",
            "Accept-Encoding": "gzip, deflate, br"
        }
        
        response = requests.get(url, headers=headers)
        
        if response.status_code != 200:
            raise ValueError(f"Failed to fetch NSE holidays. Status code: {response.status_code}")
            
        data = response.json()
        
        if 'CM' not in data:
            raise ValueError("Unexpected data format from NSE API")
            
        holidays = []
        for item in data['CM']:
            holidays.append({
                'date': datetime.strptime(item['tradingDate'], '%d-%b-%Y').date(),
                'description': item['description']
            })
            
        holidays_df = pd.DataFrame(holidays)
        return holidays_df
    
    def _get_fallback_holidays(self) -> pd.DataFrame:
        """
        Get fallback holiday list for current year
        """
        current_year = datetime.now().year
        
        # Common Indian holidays (dates vary by year, this is approximate)
        holidays = [
            {'date': date(current_year, 1, 26), 'description': 'Republic Day'},
            {'date': date(current_year, 8, 15), 'description': 'Independence Day'},
            {'date': date(current_year, 10, 2), 'description': 'Gandhi Jayanti'},
            {'date': date(current_year, 1, 1), 'description': 'New Year'}
            # Add more common holidays
        ]
        
        return pd.DataFrame(holidays)
    
    def is_trading_day(self, check_date: Optional[date] = None) -> bool:
        """
        Check if a date is a trading day
        """
        # Use current date if none provided
        if check_date is None:
            check_date = datetime.now().date()
            
        # Weekend check
        if check_date.weekday() >= 5:  # 5 = Saturday, 6 = Sunday
            return False
            
        # Holiday check
        holiday_dates = pd.to_datetime(self.nse_holidays['date']).dt.date
        if check_date in holiday_dates.values:
            return False
            
        # If not weekend or holiday, it's a trading day
        return True
    
    def get_next_trading_day(self, from_date: Optional[date] = None) -> date:
        """
        Get the next trading day from a given date
        """
        # Use current date if none provided
        if from_date is None:
            from_date = datetime.now().date()
            
        # Check the next 10 days at most
        for i in range(1, 10):
            next_date = from_date + timedelta(days=i)
            if self.is_trading_day(next_date):
                return next_date
                
        # If no trading day found in the next 10 days, return the next Monday
        days_until_monday = (7 - from_date.weekday()) % 7
        if days_until_monday == 0:
            days_until_monday = 7
        return from_date + timedelta(days=days_until_monday)
    
    def get_trading_hours(self, exchange: str = 'NSE') -> Dict[str, str]:
        """
        Get trading hours for a specific exchange
        """
        return self.exchange_timing.get(exchange.upper(), self.exchange_timing['NSE'])
    
    def is_market_open(self, exchange: str = 'NSE') -> bool:
        """
        Check if market is currently open
        """
        # Check if today is a trading day
        if not self.is_trading_day():
            return False
            
        # Get current time in India
        now = datetime.now()
        
        # Get trading hours
        hours = self.get_trading_hours(exchange)
        
        # Parse trading hours
        open_time = datetime.strptime(hours['open'], '%H:%M').time()
        close_time = datetime.strptime(hours['close'], '%H:%M').time()
        
        # Check if current time is within trading hours
        current_time = now.time()
        return open_time <= current_time <= close_time
    
    def time_to_market_open(self, exchange: str = 'NSE') -> Optional[timedelta]:
        """
        Get time remaining until market opens
        Returns None if market is already open or not opening today
        """
        # If market is already open
        if self.is_market_open(exchange):
            return None
            
        # If today is not a trading day
        today = datetime.now().date()
        if not self.is_trading_day(today):
            return None
            
        # Get current time
        now = datetime.now()
        
        # Get trading hours
        hours = self.get_trading_hours(exchange)
        
        # Parse opening time
        open_time = datetime.strptime(hours['open'], '%H:%M').time()
        
        # Create datetime for market open today
        market_open = datetime.combine(today, open_time)
        
        # If market open time is in the past, no more openings today
        if market_open < now:
            return None
            
        # Return time until market open
        return market_open - now
    
    def time_to_market_close(self, exchange: str = 'NSE') -> Optional[timedelta]:
        """
        Get time remaining until market closes
        Returns None if market is already closed or not open today
        """
        # If market is not open
        if not self.is_market_open(exchange):
            return None
            
        # Get current time
        now = datetime.now()
        
        # Get trading hours
        hours = self.get_trading_hours(exchange)
        
        # Parse closing time
        close_time = datetime.strptime(hours['close'], '%H:%M').time()
        
        # Create datetime for market close today
        market_close = datetime.combine(now.date(), close_time)
        
        # Return time until market close
        return market_close - now
