"""
Alert System with multilingual support (English and Gujarati)
"""
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import requests
import json
from typing import Dict, List, Optional, Union
from loguru import logger
from googletrans import Translator


class AlertSystem:
    """
    Alert system for sending notifications with multilingual support
    """
    def __init__(self, config: Dict):
        self.config = config
        self.translator = Translator()
        
        # Set up email settings if available
        self.email_settings = config.get('email', {})
        self.email_enabled = self.email_settings.get('enabled', False)
        
        # Set up SMS settings if available
        self.sms_settings = config.get('sms', {})
        self.sms_enabled = self.sms_settings.get('enabled', False)
        
        # Set up telegram settings if available
        self.telegram_settings = config.get('telegram', {})
        self.telegram_enabled = self.telegram_settings.get('enabled', False)
        
        # Financial terms glossary for better translation
        self.financial_terms = {
            'buy': 'ખરીદો',
            'sell': 'વેચો',
            'option': 'ઑપ્શન',
            'call': 'કૉલ',
            'put': 'પુટ',
            'strike': 'સ્ટ્રાઇક',
            'premium': 'પ્રીમિયમ',
            'expiry': 'સમાપ્તિ',
            'profit': 'નફો',
            'loss': 'નુકસાન',
            'market': 'બજાર',
            'price': 'ભાવ',
            'trade': 'ટ્રેડ'
        }
    
    def send_alert(self, title: str, message: str, languages: List[str] = None, priority: str = 'normal'):
        """
        Send an alert using configured channels with multilingual support
        
        Args:
            title: Alert title
            message: Alert message
            languages: List of language codes ('en', 'gu')
            priority: Alert priority ('low', 'normal', 'high', 'critical')
        """
        try:
            # Default to English if no languages specified
            languages = languages or ['en']
            
            # Prepare messages in each language
            messages = {}
            messages['en'] = {'title': title, 'message': message}
            
            # Translate to other languages
            for lang in languages:
                if lang != 'en' and lang == 'gu':  # Gujarati
                    messages['gu'] = {
                        'title': self._translate_to_gujarati(title),
                        'message': self._translate_to_gujarati(message)
                    }
            
            # Send via each enabled channel
            if self.email_enabled:
                self._send_email_alert(messages, languages, priority)
                
            if self.sms_enabled:
                self._send_sms_alert(messages, languages, priority)
                
            if self.telegram_enabled:
                self._send_telegram_alert(messages, languages, priority)
                
            # Log the alert
            logger.info(f"Alert sent: {title} (Priority: {priority})")
            
            return True
            
        except Exception as e:
            logger.error(f"Error sending alert: {str(e)}")
            return False
    
    def send_critical_alert(self, title: str, message: str):
        """
        Send a critical alert (shorthand for high priority)
        """
        return self.send_alert(title, message, languages=['en', 'gu'], priority='critical')
    
    def _translate_to_gujarati(self, text: str) -> str:
        """
        Translate text to Gujarati with special handling for financial terms
        """
        try:
            # First replace known financial terms
            for en_term, gu_term in self.financial_terms.items():
                text = text.replace(f" {en_term} ", f" {gu_term} ")
            
            # Then translate remaining text
            translated = self.translator.translate(text, src='en', dest='gu')
            return translated.text
        except Exception as e:
            logger.error(f"Translation error: {str(e)}")
            return text  # Return original text if translation fails
    
    def _send_email_alert(self, messages: Dict, languages: List[str], priority: str):
        """
        Send alert via email
        """
        if not self.email_enabled:
            return
            
        try:
            # Set up email
            msg = MIMEMultipart('alternative')
            
            # Use English as default subject
            msg['Subject'] = f"AGTI Alert: {messages['en']['title']}"
            msg['From'] = self.email_settings.get('from', 'alerts@agti.com')
            msg['To'] = ', '.join(self.email_settings.get('recipients', []))
            
            # Create HTML content with all language versions
            html = "<html><body>"
            
            # Add priority indicator
            priority_colors = {
                'low': '#28a745',
                'normal': '#007bff',
                'high': '#ffc107',
                'critical': '#dc3545'
            }
            
            html += f"<div style='background-color: {priority_colors.get(priority, '#007bff')}; color: white; padding: 10px; font-weight: bold;'>"
            html += f"Priority: {priority.upper()}</div><br>"
            
            # Add each language version
            for lang in languages:
                if lang in messages:
                    if lang == 'gu':  # Gujarati
                        html += f"<div style='font-family: \"Nirmala UI\", Arial, sans-serif;'>"
                        html += f"<h2>{messages[lang]['title']}</h2>"
                        html += f"<p>{messages[lang]['message']}</p>"
                        html += "</div><hr>"
                    else:  # English or other languages
                        html += f"<div>"
                        html += f"<h2>{messages[lang]['title']}</h2>"
                        html += f"<p>{messages[lang]['message']}</p>"
                        html += "</div><hr>"
            
            html += "</body></html>"
            
            # Attach HTML content
            msg.attach(MIMEText(html, 'html'))
            
            # Send email
            server = smtplib.SMTP(
                self.email_settings.get('smtp_server', 'localhost'),
                self.email_settings.get('smtp_port', 25)
            )
            
            if self.email_settings.get('use_tls', False):
                server.starttls()
                
            if self.email_settings.get('username') and self.email_settings.get('password'):
                server.login(
                    self.email_settings.get('username'),
                    self.email_settings.get('password')
                )
                
            server.send_message(msg)
            server.quit()
            
            logger.debug("Email alert sent successfully")
            
        except Exception as e:
            logger.error(f"Error sending email alert: {str(e)}")
    
    def _send_sms_alert(self, messages: Dict, languages: List[str], priority: str):
        """
        Send alert via SMS
        """
        if not self.sms_enabled:
            return
            
        try:
            # Prioritize sending Gujarati if in languages
            lang = 'gu' if 'gu' in languages and 'gu' in messages else 'en'
            
            # Construct SMS body
            body = f"{messages[lang]['title']}: {messages[lang]['message']}"
            
            # Truncate if too long
            if len(body) > 160:
                body = body[:157] + "..."
                
            # Send SMS using configured provider
            provider = self.sms_settings.get('provider', 'twilio')
            
            if provider == 'twilio':
                self._send_twilio_sms(body, priority)
            else:
                logger.warning(f"Unsupported SMS provider: {provider}")
                
            logger.debug("SMS alert sent successfully")
            
        except Exception as e:
            logger.error(f"Error sending SMS alert: {str(e)}")
    
    def _send_twilio_sms(self, body: str, priority: str):
        """
        Send SMS via Twilio
        """
        # This is a placeholder for Twilio integration
        # You would implement actual Twilio API calls here
        logger.info(f"[TWILIO SMS PLACEHOLDER] Priority: {priority}, Body: {body}")
    
    def _send_telegram_alert(self, messages: Dict, languages: List[str], priority: str):
        """
        Send alert via Telegram
        """
        if not self.telegram_enabled:
            return
            
        try:
            # Get bot token and chat IDs
            token = self.telegram_settings.get('bot_token')
            chat_ids = self.telegram_settings.get('chat_ids', [])
            
            if not token or not chat_ids:
                logger.warning("Telegram bot token or chat IDs not configured")
                return
                
            # Send message for each language and chat ID
            for lang in languages:
                if lang in messages:
                    message_text = f"*{messages[lang]['title']}*\n\n{messages[lang]['message']}"
                    
                    # Add priority indicator
                    priority_icons = {
                        'low': '🟢',
                        'normal': '🔵',
                        'high': '🟡',
                        'critical': '🔴'
                    }
                    
                    message_text = f"{priority_icons.get(priority, '🔵')} {message_text}"
                    
                    # Send to each chat ID
                    for chat_id in chat_ids:
                        url = f"https://api.telegram.org/bot{token}/sendMessage"
                        payload = {
                            'chat_id': chat_id,
                            'text': message_text,
                            'parse_mode': 'Markdown'
                        }
                        
                        response = requests.post(url, json=payload)
                        
                        if response.status_code != 200:
                            logger.warning(f"Telegram API error: {response.text}")
            
            logger.debug("Telegram alert sent successfully")
            
        except Exception as e:
            logger.error(f"Error sending Telegram alert: {str(e)}")
