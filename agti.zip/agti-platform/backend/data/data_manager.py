"""
Data Manager for AGTI platform
"""
import pandas as pd
import numpy as np
import os
import aiohttp
import asyncio
from datetime import datetime, timedelta
import pytz
from typing import Dict, List, Optional, Any
from loguru import logger

from brokers.broker_manager import BrokerManager


class DataManager:
    """
    Centralized data management for historical, real-time, and alternative data
    """
    def __init__(self, config: Dict):
        self.config = config
        self.cache = {}  # In-memory cache
        self.datasets = {}  # Named datasets
        self.india_tz = pytz.timezone('Asia/Kolkata')
        self.broker_manager = None
        self.historical_data_path = config.get('historical_path', 'data/historical')
        
        # Ensure data directories exist
        os.makedirs(self.historical_data_path, exist_ok=True)
    
    async def initialize(self):
        """Initialize data manager and load essential data"""
        logger.info("Initializing DataManager")
        # Any additional initialization
    
    def set_broker_manager(self, broker_manager: BrokerManager):
        """Set the broker manager for real-time data access"""
        self.broker_manager = broker_manager
    
    async def load_historical_data(self, symbol: str, years: int = 15, exchange: str = 'NSE') -> pd.DataFrame:
        """
        Load historical data for a symbol with default 15 years
        If data doesn't exist locally, download it
        """
        try:
            file_path = os.path.join(self.historical_data_path, exchange.lower(), f"{symbol}.parquet")
            
            # Check if file exists
            if os.path.exists(file_path):
                df = pd.read_parquet(file_path)
                logger.info(f"Loaded historical data for {symbol} from file")
                return df
            
            # File doesn't exist, download data
            logger.info(f"Historical data file not found for {symbol}, downloading...")
            
            # Calculate date range
            end_date = datetime.now(self.india_tz)
            start_date = end_date - timedelta(days=years*365)
            
            # Try to get from broker
            if self.broker_manager:
                df = await self.broker_manager.get_historical_data(
                    symbol=symbol,
                    interval='day',
                    from_date=start_date.strftime('%Y-%m-%d'),
                    to_date=end_date.strftime('%Y-%m-%d')
                )
                
                if not df.empty:
                    # Save to file
                    os.makedirs(os.path.dirname(file_path), exist_ok=True)
                    df.to_parquet(file_path)
                    logger.info(f"Downloaded and saved historical data for {symbol}")
                    return df
            
            # If broker data not available, try alternative source
            df = await self._download_historical_data(symbol, start_date, end_date, exchange)
            
            if not df.empty:
                # Save to file
                os.makedirs(os.path.dirname(file_path), exist_ok=True)
                df.to_parquet(file_path)
                logger.info(f"Downloaded and saved historical data for {symbol} from alternative source")
            
            return df
            
        except Exception as e:
            logger.error(f"Error loading historical data for {symbol}: {str(e)}")
            return pd.DataFrame()
    
    async def _download_historical_data(self, symbol: str, start_date: datetime, end_date: datetime, exchange: str) -> pd.DataFrame:
        """
        Download historical data from alternative source
        """
        try:
            # This is a placeholder - you would implement your data source API call here
            # For example, using Yahoo Finance or other data provider
            
            # Simulate data for now
            date_range = pd.date_range(start=start_date, end=end_date, freq='D')
            prices = np.random.normal(100, 10, len(date_range))
            prices = np.cumsum(np.random.normal(0, 1, len(date_range))) + 100  # Random walk
            
            df = pd.DataFrame({
                'date': date_range,
                'open': prices * (1 + np.random.normal(0, 0.01, len(date_range))),
                'high': prices * (1 + np.random.normal(0, 0.02, len(date_range))),
                'low': prices * (1 - np.random.normal(0, 0.02, len(date_range))),
                'close': prices,
                'volume': np.random.randint(100000, 1000000, len(date_range))
            })
            
            # Add Indian market specific columns
            df['symbol'] = symbol
            df['exchange'] = exchange
            
            return df
            
        except Exception as e:
            logger.error(f"Error downloading historical data: {str(e)}")
            return pd.DataFrame()
    
    def store_dataset(self, name: str, df: pd.DataFrame):
        """Store a named dataset in memory"""
        self.datasets[name] = df
        logger.debug(f"Stored dataset '{name}' with {len(df)} records")
    
    def get_dataset(self, name: str) -> Optional[pd.DataFrame]:
        """Retrieve a named dataset"""
        return self.datasets.get(name)
    
    async def get_options_chain(self, symbol: str) -> pd.DataFrame:
        """
        Get options chain data for a symbol
        """
        try:
            if self.broker_manager:
                # Try to get from broker
                options_chain = await self.broker_manager.get_options_chain(symbol)
                
                if not options_chain.empty:
                    # Calculate implied volatility and Greeks
                    options_chain = self._calculate_options_metrics(options_chain, symbol)
                    return options_chain
            
            # If broker data not available, try alternative source
            return await self._get_options_chain_alternative(symbol)
            
        except Exception as e:
            logger.error(f"Error getting options chain for {symbol}: {str(e)}")
            return pd.DataFrame()
    
    def _calculate_options_metrics(self, options_chain: pd.DataFrame, underlying: str) -> pd.DataFrame:
        """
        Calculate implied volatility and Greeks for options chain
        """
        try:
            # Get underlying price
            underlying_price = options_chain['underlying_price'].iloc[0] if 'underlying_price' in options_chain.columns else 0
            
            if underlying_price == 0 and self.broker_manager:
                # Try to get from broker
                underlying_price = asyncio.run(self.broker_manager.get_ltp(underlying))
            
            if underlying_price > 0:
                # Calculate days to expiry
                if 'expiry' in options_chain.columns:
                    options_chain['days_to_expiry'] = (pd.to_datetime(options_chain['expiry']) - pd.Timestamp.now()).dt.days
                
                # This is a placeholder - you would implement the actual IV and Greeks calculation
                # For example, using py_vollib or other options pricing library
                
                # Simulate IV for now
                options_chain['implied_volatility'] = np.random.uniform(0.2, 0.4, len(options_chain))
                
                # Simulate Greeks
                options_chain['delta'] = np.random.uniform(-1, 1, len(options_chain))
                options_chain['gamma'] = np.random.uniform(0, 0.1, len(options_chain))
                options_chain['theta'] = np.random.uniform(-0.1, 0, len(options_chain))
                options_chain['vega'] = np.random.uniform(0, 0.1, len(options_chain))
            
            return options_chain
            
        except Exception as e:
            logger.error(f"Error calculating options metrics: {str(e)}")
            return options_chain
    
    async def _get_options_chain_alternative(self, symbol: str) -> pd.DataFrame:
        """
        Get options chain from alternative source
        """
        try:
            # This is a placeholder - you would implement your data source API call here
            
            # Simulate data for now
            strikes = range(int(100 - 50), int(100 + 50), 10)  # Range of strikes around 100
            expiries = [
                (datetime.now() + timedelta(days=7)).strftime('%Y-%m-%d'),
                (datetime.now() + timedelta(days=14)).strftime('%Y-%m-%d'),
                (datetime.now() + timedelta(days=30)).strftime('%Y-%m-%d')
            ]
            
            data = []
            for expiry in expiries:
                for strike in strikes:
                    # Call option
                    data.append({
                        'symbol': f"{symbol}{expiry.replace('-', '')}C{strike}",
                        'underlying': symbol,
                        'strike': strike,
                        'expiry': expiry,
                        'option_type': 'CE',
                        'last_price': max(0, 100 - strike) + 5,  # Simple pricing model
                        'volume': np.random.randint(1000, 10000),
                        'oi': np.random.randint(10000, 100000),
                        'underlying_price': 100
                    })
                    
                    # Put option
                    data.append({
                        'symbol': f"{symbol}{expiry.replace('-', '')}P{strike}",
                        'underlying': symbol,
                        'strike': strike,
                        'expiry': expiry,
                        'option_type': 'PE',
                        'last_price': max(0, strike - 100) + 5,  # Simple pricing model
                        'volume': np.random.randint(1000, 10000),
                        'oi': np.random.randint(10000, 100000),
                        'underlying_price': 100
                    })
            
            df = pd.DataFrame(data)
            
            # Calculate implied volatility and Greeks
            df = self._calculate_options_metrics(df, symbol)
            
            return df
            
        except Exception as e:
            logger.error(f"Error getting options chain from alternative source: {str(e)}")
            return pd.DataFrame()
    
    async def get_latest_news(self, symbols: List[str] = None, language: str = 'en') -> List[Dict]:
        """
        Get latest news for specified symbols
        Supports English and Gujarati languages
        """
        try:
            # This is a placeholder - you would implement your news API call here
            
            # Simulate news for now
            news_items = []
            
            # Use symbols if provided, otherwise use a default set
            symbols = symbols or ['NIFTY', 'BANKNIFTY', 'RELIANCE', 'HDFCBANK']
            
            for symbol in symbols:
                news_items.append({
                    'symbol': symbol,
                    'title': f"Latest news about {symbol}",
                    'content': f"This is a simulated news item about {symbol} for testing purposes.",
                    'source': "AGTI News",
                    'timestamp': datetime.now().isoformat(),
                    'language': language,
                    'url': f"https://example.com/news/{symbol.lower()}"
                })
            
            # If Gujarati is requested, translate
            if language == 'gu' or language == 'mixed':
                # This is a placeholder for translation
                for item in news_items:
                    item['title_gujarati'] = f"{item['symbol']} વિશે તાજા સમાચાર"
                    item['content_gujarati'] = f"આ {item['symbol']} વિશે પરીક્ષણ હેતુઓ માટે એક નકલી સમાચાર છે."
            
            return news_items
            
        except Exception as e:
            logger.error(f"Error getting latest news: {str(e)}")
            return []
    
    async def get_oi_data(self, symbol: str) -> pd.DataFrame:
        """
        Get open interest data for a symbol
        """
        try:
            if self.broker_manager:
                # Try to get options chain which includes OI data
                options_chain = await self.get_options_chain(symbol)
                
                if not options_chain.empty and 'oi' in options_chain.columns:
                    # Extract OI data
                    oi_data = options_chain[['strike', 'option_type', 'oi', 'volume']]
                    return oi_data
            
            # If broker data not available, try alternative source
            return await self._get_oi_data_alternative(symbol)
            
        except Exception as e:
            logger.error(f"Error getting OI data for {symbol}: {str(e)}")
            return pd.DataFrame()
    
    async def _get_oi_data_alternative(self, symbol: str) -> pd.DataFrame:
        """
        Get open interest data from alternative source
        """
        try:
            # This is a placeholder - you would implement your data source API call here
            
            # Simulate data for now
            strikes = range(int(100 - 50), int(100 + 50), 10)  # Range of strikes around 100
            
            data = []
            for strike in strikes:
                # Call option
                data.append({
                    'strike': strike,
                    'option_type': 'CE',
                    'oi': np.random.randint(10000, 100000),
                    'volume': np.random.randint(1000, 10000)
                })
                
                # Put option
                data.append({
                    'strike': strike,
                    'option_type': 'PE',
                    'oi': np.random.randint(10000, 100000),
                    'volume': np.random.randint(1000, 10000)
                })
            
            return pd.DataFrame(data)
            
        except Exception as e:
            logger.error(f"Error getting OI data from alternative source: {str(e)}")
            return pd.DataFrame()
    
    def get_ltp(self, symbol: str) -> float:
        """
        Get last traded price for a symbol (sync wrapper for async function)
        """
        try:
            if self.broker_manager:
                return asyncio.run(self.broker_manager.get_ltp(symbol))
            return 0.0
        except Exception as e:
            logger.error(f"Error getting LTP for {symbol}: {str(e)}")
            return 0.0
