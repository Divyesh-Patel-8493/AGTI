#!/usr/bin/env python3
"""
Main entry point for the Autonomous Global Trading Intelligence Platform
"""
import asyncio
import signal
from typing import Dict, List
from loguru import logger
import pandas as pd

from core.agent_framework import Agent
from core.market_analysis import (
    OptionsAnalysisAgent,
    NewsSentimentAgent,
    ParticipantDetectionAgent
)
from core.risk_management import (
    RiskManagementAgent,
    PortfolioOptimizationAgent
)
from core.trade_execution import (
    OptionsExecutionAgent,
    SmartOrderRouterAgent
)
from data.data_manager import DataManager
from brokers.broker_manager import BrokerManager
from utils.config_manager import load_config
from utils.alert_system import AlertSystem
from utils.performance_tracker import PerformanceTracker
from utils.holiday_manager import HolidayManager

class AGTIPlatform:
    def __init__(self, config_path: str = "config/production.yaml"):
        """Initialize the autonomous trading platform"""
        self.config = load_config(config_path)
        self._setup_logging()
        self.running = False
        self.agents: List[Agent] = []

        # Core components
        self.data_manager = DataManager(self.config['data'])
        self.broker_manager = BrokerManager(self.config['brokers'])
        self.alert_system = AlertSystem(self.config['alerts'])
        self.performance_tracker = PerformanceTracker()
        self.holiday_manager = HolidayManager()

        # Indian market specific initialization
        self.indian_market_config = self.config['markets']['india']

    def _setup_logging(self):
        """Configure logging system"""
        logger.add(
            "logs/platform_{time}.log",
            rotation="1 day",
            retention="7 days",
            level=self.config.get('log_level', 'INFO')
        )

    def initialize_agents(self):
        """Initialize all AI agents"""
        logger.info("Initializing AI agents...")

        # Market Analysis Agents
        self.agents.append(
            OptionsAnalysisAgent(
                self.config['agents']['options_analysis'],
                self.data_manager,
                self.broker_manager
            )
        )

        self.agents.append(
            NewsSentimentAgent(
                self.config['agents']['news_sentiment'],
                self.data_manager,
                language='mixed'  # For English and Gujarati
            )
        )

        self.agents.append(
            ParticipantDetectionAgent(
                self.config['agents']['participant_detection'],
                self.data_manager
            )
        )

        # Risk Management Agents
        self.agents.append(
            RiskManagementAgent(
                self.config['agents']['risk_management'],
                self.broker_manager,
                initial_capital=self.indian_market_config['initial_capital']  # ₹5,000
            )
        )

        self.agents.append(
            PortfolioOptimizationAgent(
                self.config['agents']['portfolio_optimization'],
                self.data_manager,
                self.broker_manager
            )
        )

        # Execution Agents
        self.agents.append(
            OptionsExecutionAgent(
                self.config['agents']['options_execution'],
                self.broker_manager,
                self.alert_system
            )
        )

        self.agents.append(
            SmartOrderRouterAgent(
                self.config['agents']['order_router'],
                self.broker_manager,
                self.data_manager
            )
        )

        # Initialize all agents
        for agent in self.agents:
            agent.initialize()

        logger.success(f"Initialized {len(self.agents)} agents")

    async def run_agent_loop(self):
        """Main asynchronous execution loop"""
        logger.info("Starting main trading loop")

        while self.running:
            if not self.holiday_manager.is_trading_day():
                logger.info("Market closed today (Holiday)")
                await asyncio.sleep(3600)  # Sleep for an hour
                continue

            start_time = pd.Timestamp.now()

            try:
                # Execute all agents concurrently
                await asyncio.gather(*[
                    agent.execute_async()
                    for agent in self.agents
                ])

                # Track performance
                self.performance_tracker.record_iteration()

                # Calculate sleep time to maintain desired interval
                elapsed = (pd.Timestamp.now() - start_time).total_seconds()
                sleep_time = max(
                    0,
                    self.config['execution_interval_seconds'] - elapsed
                )
                await asyncio.sleep(sleep_time)

            except Exception as e:
                logger.error(f"Error in main loop: {e}")
                self.alert_system.send_critical_alert(
                    "Platform Error",
                    f"Critical error occurred: {str(e)}"
                )
                # Recovery logic
                await self.broker_manager.ensure_connection()

    def shutdown(self, sig=None, frame=None):
        """Graceful shutdown procedure"""
        logger.info("Shutting down platform...")
        self.running = False

        # Clean up all agents
        for agent in self.agents:
            if hasattr(agent, 'shutdown'):
                agent.shutdown()

        # Final performance report
        self.performance_tracker.generate_report()
        logger.success("Platform shutdown complete")

    async def main(self):
        """Main entry point"""
        # Register signal handlers
        signal.signal(signal.SIGINT, self.shutdown)
        signal.signal(signal.SIGTERM, self.shutdown)

        # Initialize components
        await self.data_manager.initialize()
        await self.broker_manager.connect()
        self.initialize_agents()

        # Load 15 years of historical data for Indian markets
        await self._load_historical_data()

        # Start main loop
        self.running = True
        await self.run_agent_loop()

    async def _load_historical_data(self):
        """Load 15 years of historical data for training"""
        logger.info("Loading historical data for Indian markets...")

        nse_symbols = self.indian_market_config['nse_symbols']
        for symbol in nse_symbols:
            try:
                df = await self.data_manager.load_historical_data(
                    symbol, years=15, exchange='NSE'
                )
                logger.info(f"Loaded {len(df)} records for {symbol}")

                # Store for agent access
                self.data_manager.store_dataset(
                    f"historical_{symbol}", df
                )

            except Exception as e:
                logger.error(f"Failed to load data for {symbol}: {e}")
                self.alert_system.send_alert(
                    "Data Load Error",
                    f"Failed to load historical data for {symbol}"
                )


if __name__ == "__main__":
    platform = AGTIPlatform()
    try:
        asyncio.run(platform.main())
    except KeyboardInterrupt:
        platform.shutdown()
    except Exception as e:
        logger.critical(f"Fatal error: {e}")
        platform.shutdown()
        raise
