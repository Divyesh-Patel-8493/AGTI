"""
Zerodha Kite Connect broker implementation
"""
import os
import pandas as pd
from typing import Dict, List, Optional
import asyncio
from kiteconnect import KiteConnect
from kiteconnect import KiteTicker
from loguru import logger

from backend.brokers.abstract_broker import AbstractBroker
from backend.brokers.zerodha.constants import EXCHANGE_MAP, PRODUCT_MAP, ORDER_TYPE_MAP
from backend.brokers.zerodha.utils import parse_zerodha_position, parse_zerodha_holding


class ZerodhaBroker(AbstractBroker):
    """Zerodha Kite Connect broker implementation"""
    
    def __init__(self):
        self.kite = None
        self.ticker = None
        self.instruments = pd.DataFrame()
        self.access_token = None
        self.api_key = None
        self._market_data_callbacks = {}
        self._connected = False
        
    async def connect(self, credentials: Dict) -> bool:
        """Authenticate with Zerodha Kite API"""
        try:
            self.api_key = credentials['api_key']
            self.access_token = credentials['access_token']
            
            # Initialize KiteConnect
            self.kite = KiteConnect(api_key=self.api_key)
            self.kite.set_access_token(self.access_token)
            
            # Initialize WebSocket
            self.ticker = KiteTicker(
                api_key=self.api_key,
                access_token=self.access_token
            )
            
            # Set WebSocket callbacks
            self.ticker.on_connect = self._on_connect
            self.ticker.on_close = self._on_close
            self.ticker.on_ticks = self._on_ticks
            self.ticker.on_error = self._on_error
            
            # Load instruments data
            await self._load_instruments()
            
            # Start ticker in a separate thread
            self.ticker_task = asyncio.create_task(self._start_ticker())
            
            self._connected = True
            logger.info("Connected to Zerodha successfully")
            return True
            
        except Exception as e:
            logger.error(f"Failed to connect to Zerodha: {str(e)}")
            self._connected = False
            return False
    
    async def _load_instruments(self):
        """Load all NSE instruments"""
        loop = asyncio.get_event_loop()
        nse_instruments = await loop.run_in_executor(None, self.kite.instruments, "NSE")
        bse_instruments = await loop.run_in_executor(None, self.kite.instruments, "BSE")
        nfo_instruments = await loop.run_in_executor(None, self.kite.instruments, "NFO")
        
        self.instruments = pd.DataFrame(nse_instruments + bse_instruments + nfo_instruments)
        logger.info(f"Loaded {len(self.instruments)} instruments")
    
    async def _start_ticker(self):
        """Start the WebSocket connection in an async-friendly way"""
        loop = asyncio.get_event_loop()
        await loop.run_in_executor(None, self.ticker.connect)
    
    async def place_order(self, order_params: Dict) -> Dict:
        """Place an order with Zerodha"""
        try:
            # Map our standard order params to Zerodha specific params
            zerodha_params = {
                "exchange": EXCHANGE_MAP.get(order_params.get('exchange', 'NSE'), "NSE"),
                "tradingsymbol": order_params['symbol'],
                "transaction_type": order_params['side'].upper(),
                "quantity": order_params['quantity'],
                "product": PRODUCT_MAP.get(order_params.get('product_type', 'MIS'), "MIS"),
                "order_type": ORDER_TYPE_MAP.get(order_params.get('order_type', 'MARKET'), "MARKET"),
                "validity": "DAY"
            }
            
            # Add optional parameters
            if 'price' in order_params:
                zerodha_params['price'] = order_params['price']
            if 'trigger_price' in order_params:
                zerodha_params['trigger_price'] = order_params['trigger_price']
                
            # Execute in thread pool
            loop = asyncio.get_event_loop()
            order_id = await loop.run_in_executor(
                None,
                lambda: self.kite.place_order(variety="regular", **zerodha_params)
            )
            
            return {"order_id": order_id, "status": "success"}
            
        except Exception as e:
            logger.error(f"Failed to place order: {str(e)}")
            return {"status": "error", "message": str(e)}
    
    async def modify_order(self, order_id: str, order_params: Dict) -> Dict:
        """Modify an existing order"""
        try:
            # Prepare parameters
            zerodha_params = {
                "order_id": order_id,
            }
            
            # Add modifiable parameters
            if 'quantity' in order_params:
                zerodha_params['quantity'] = order_params['quantity']
            if 'price' in order_params:
                zerodha_params['price'] = order_params['price']
            if 'trigger_price' in order_params:
                zerodha_params['trigger_price'] = order_params['trigger_price']
            if 'order_type' in order_params:
                zerodha_params['order_type'] = ORDER_TYPE_MAP.get(order_params['order_type'], "LIMIT")
                
            # Execute in thread pool
            loop = asyncio.get_event_loop()
            result = await loop.run_in_executor(
                None,
                lambda: self.kite.modify_order(variety="regular", **zerodha_params)
            )
            
            return {"order_id": result, "status": "success"}
            
        except Exception as e:
            logger.error(f"Failed to modify order: {str(e)}")
            return {"status": "error", "message": str(e)}
    
    async def cancel_order(self, order_id: str) -> Dict:
        """Cancel an existing order"""
        try:
            # Execute in thread pool
            loop = asyncio.get_event_loop()
            result = await loop.run_in_executor(
                None,
                lambda: self.kite.cancel_order(variety="regular", order_id=order_id)
            )
            
            return {"order_id": result, "status": "success"}
            
        except Exception as e:
            logger.error(f"Failed to cancel order: {str(e)}")
            return {"status": "error", "message": str(e)}
    
    async def get_order_status(self, order_id: str) -> Dict:
        """Check status of an order"""
        try:
            # Execute in thread pool
            loop = asyncio.get_event_loop()
            orders = await loop.run_in_executor(
                None,
                self.kite.orders
            )
            
            # Find specific order
            for order in orders:
                if order['order_id'] == order_id:
                    return order
                    
            return {"status": "not_found", "order_id": order_id}
            
        except Exception as e:
            logger.error(f"Failed to get order status: {str(e)}")
            return {"status": "error", "message": str(e)}
    
    async def get_positions(self) -> pd.DataFrame:
        """Get current positions from Zerodha"""
        try:
            # Execute in thread pool
            loop = asyncio.get_event_loop()
            positions = await loop.run_in_executor(
                None,
                self.kite.positions
            )
            
            return parse_zerodha_position(positions)
            
        except Exception as e:
            logger.error(f"Failed to get positions: {str(e)}")
            return pd.DataFrame()
    
    async def get_holdings(self) -> pd.DataFrame:
        """Get current holdings from Zerodha"""
        try:
            # Execute in thread pool
            loop = asyncio.get_event_loop()
            holdings = await loop.run_in_executor(
                None,
                self.kite.holdings
            )
            
            return parse_zerodha_holding(holdings)
            
        except Exception as e:
            logger.error(f"Failed to get holdings: {str(e)}")
            return pd.DataFrame()
    
    async def get_ltp(self, symbol: str) -> float:
        """Get last traded price for a symbol"""
        try:
            # Parse exchange and tradingsymbol
            if ':' in symbol:
                exchange, tradingsymbol = symbol.split(':')
            else:
                exchange = "NSE"
                tradingsymbol = symbol
                
            # Execute in thread pool
            loop = asyncio.get_event_loop()
            ltp_data = await loop.run_in_executor(
                None,
                lambda: self.kite.ltp([f"{exchange}:{tradingsymbol}"])
            )
            
            # Extract LTP
            key = f"{exchange}:{tradingsymbol}"
            if key in ltp_data:
                return ltp_data[key]['last_price']
            return 0.0
            
        except Exception as e:
            logger.error(f"Failed to get LTP for {symbol}: {str(e)}")
            return 0.0
    
    async def get_historical_data(self, symbol: str, interval: str, from_date: str, to_date: str) -> pd.DataFrame:
        """Get historical data for a symbol"""
        try:
            # Determine instrument token
            instrument = None
            if ':' in symbol:
                exchange, tradingsymbol = symbol.split(':')
                instrument = self.instruments[
                    (self.instruments['tradingsymbol'] == tradingsymbol) & 
                    (self.instruments['exchange'] == exchange)
                ]
            else:
                instrument = self.instruments[
                    (self.instruments['tradingsymbol'] == symbol) & 
                    (self.instruments['exchange'] == 'NSE')
                ]
                
            if instrument.empty:
                raise ValueError(f"Instrument not found: {symbol}")
                
            instrument_token = instrument.iloc[0]['instrument_token']
            
            # Execute in thread pool
            loop = asyncio.get_event_loop()
            data = await loop.run_in_executor(
                None,
                lambda: self.kite.historical_data(
                    instrument_token=instrument_token,
                    from_date=from_date,
                    to_date=to_date,
                    interval=interval,
                    continuous=False,
                    oi=True
                )
            )
            
            return pd.DataFrame(data)
            
        except Exception as e:
            logger.error(f"Failed to get historical data for {symbol}: {str(e)}")
            return pd.DataFrame()
    
    async def subscribe_market_data(self, symbols: List[str]):
        """Subscribe to real-time market data"""
        try:
            instrument_tokens = []
            
            for symbol in symbols:
                if ':' in symbol:
                    exchange, tradingsymbol = symbol.split(':')
                    instrument = self.instruments[
                        (self.instruments['tradingsymbol'] == tradingsymbol) & 
                        (self.instruments['exchange'] == exchange)
                    ]
                else:
                    instrument = self.instruments[
                        (self.instruments['tradingsymbol'] == symbol) & 
                        (self.instruments['exchange'] == 'NSE')
                    ]
                    
                if not instrument.empty:
                    instrument_token = instrument.iloc[0]['instrument_token']
                    instrument_tokens.append(instrument_token)
            
            if instrument_tokens:
                self.ticker.subscribe(instrument_tokens)
                self.ticker.set_mode(self.ticker.MODE_FULL, instrument_tokens)
                logger.info(f"Subscribed to {len(instrument_tokens)} instruments")
        
        except Exception as e:
            logger.error(f"Failed to subscribe to market data: {str(e)}")
    
    async def unsubscribe_market_data(self, symbols: List[str]):
        """Unsubscribe from real-time market data"""
        try:
            instrument_tokens = []
            
            for symbol in symbols:
                if ':' in symbol:
                    exchange, tradingsymbol = symbol.split(':')
                    instrument = self.instruments[
                        (self.instruments['tradingsymbol'] == tradingsymbol) & 
                        (self.instruments['exchange'] == exchange)
                    ]
                else:
                    instrument = self.instruments[
                        (self.instruments['tradingsymbol'] == symbol) & 
                        (self.instruments['exchange'] == 'NSE')
                    ]
                    
                if not instrument.empty:
                    instrument_token = instrument.iloc[0]['instrument_token']
                    instrument_tokens.append(instrument_token)
            
            if instrument_tokens:
                self.ticker.unsubscribe(instrument_tokens)
                logger.info(f"Unsubscribed from {len(instrument_tokens)} instruments")
        
        except Exception as e:
            logger.error(f"Failed to unsubscribe from market data: {str(e)}")
    
    def _on_ticks(self, ws, ticks):
        """Handle incoming ticks from WebSocket"""
        for tick in ticks:
            # Process tick data
            instrument_token = tick['instrument_token']
            if instrument_token in self._market_data_callbacks:
                for callback in self._market_data_callbacks[instrument_token]:
                    asyncio.create_task(callback(tick))
    
    def _on_connect(self, ws, response):
        """Handle WebSocket connection"""
        logger.info("Connected to Zerodha WebSocket")
        self._connected = True
    
    def _on_close(self, ws, code, reason):
        """Handle WebSocket closure"""
        logger.warning(f"Zerodha WebSocket closed: {reason} (code: {code})")
        self._connected = False
        # Auto-reconnect logic
        asyncio.create_task(self._reconnect())
    
    def _on_error(self, ws, code, reason):
        """Handle WebSocket error"""
        logger.error(f"Zerodha WebSocket error: {reason} (code: {code})")
        self._connected = False
    
    async def _reconnect(self):
        """Attempt to reconnect WebSocket"""
        try:
            logger.info("Attempting to reconnect Zerodha WebSocket...")
            await asyncio.sleep(5)  # Wait before reconnecting
            
            # Reconnect
            if self.ticker:
                self.ticker.close()
                
            self.ticker = KiteTicker(
                api_key=self.api_key,
                access_token=self.access_token
            )
            
            # Set WebSocket callbacks
            self.ticker.on_connect = self._on_connect
            self.ticker.on_close = self._on_close
            self.ticker.on_ticks = self._on_ticks
            self.ticker.on_error = self._on_error
            
            # Start ticker in a separate thread
            self.ticker_task = asyncio.create_task(self._start_ticker())
            
            logger.info("Zerodha WebSocket reconnected")
            
        except Exception as e:
            logger.error(f"Failed to reconnect Zerodha WebSocket: {str(e)}")
            await asyncio.sleep(30)  # Wait longer before next attempt
            asyncio.create_task(self._reconnect())
    
    @property
    def is_connected(self) -> bool:
        """Check if currently connected to broker"""
        return self._connected
    
    async def close_position(self, position_params: Dict) -> Dict:
        """Close a specific position"""
        try:
            symbol = position_params['symbol']
            quantity = position_params.get('quantity', None)
            
            # Get current position
            positions = await self.get_positions()
            position = positions[positions['symbol'] == symbol]
            
            if position.empty:
                return {"status": "error", "message": f"No position found for {symbol}"}
            
            # Determine quantity to close
            pos_quantity = position.iloc[0]['quantity']
            if quantity is None or quantity > abs(pos_quantity):
                quantity = abs(pos_quantity)
            
            # Determine transaction type (opposite of current position)
            transaction_type = "BUY" if pos_quantity < 0 else "SELL"
            
            # Place order to close
            order_params = {
                "symbol": symbol,
                "quantity": quantity,
                "side": transaction_type,
                "order_type": "MARKET",
                "product_type": position.iloc[0]['product']
            }
            
            return await self.place_order(order_params)
            
        except Exception as e:
            logger.error(f"Failed to close position: {str(e)}")
            return {"status": "error", "message": str(e)}
