"""
Abstract Broker Interface
"""
from abc import ABC, abstractmethod
from typing import Dict, List, Optional
import pandas as pd


class AbstractBroker(ABC):
    """Abstract base class for all broker adapters"""
    
    @abstractmethod
    async def connect(self, credentials: Dict) -> bool:
        """Authenticate with broker API"""
        pass
    
    @abstractmethod
    async def place_order(self, order_params: Dict) -> Dict:
        """Place an order with the broker"""
        pass
    
    @abstractmethod
    async def modify_order(self, order_id: str, order_params: Dict) -> Dict:
        """Modify an existing order"""
        pass
    
    @abstractmethod
    async def cancel_order(self, order_id: str) -> Dict:
        """Cancel an existing order"""
        pass
    
    @abstractmethod
    async def get_order_status(self, order_id: str) -> Dict:
        """Check status of an order"""
        pass
    
    @abstractmethod
    async def get_positions(self) -> pd.DataFrame:
        """Get current positions"""
        pass
    
    @abstractmethod
    async def get_holdings(self) -> pd.DataFrame:
        """Get current holdings"""
        pass
    
    @abstractmethod
    async def get_ltp(self, symbol: str) -> float:
        """Get last traded price for a symbol"""
        pass
    
    @abstractmethod
    async def get_historical_data(self, symbol: str, interval: str, from_date: str, to_date: str) -> pd.DataFrame:
        """Get historical data for a symbol"""
        pass
    
    @abstractmethod
    async def subscribe_market_data(self, symbols: List[str]):
        """Subscribe to real-time market data"""
        pass
    
    @abstractmethod
    async def unsubscribe_market_data(self, symbols: List[str]):
        """Unsubscribe from real-time market data"""
        pass
    
    @property
    @abstractmethod
    def is_connected(self) -> bool:
        """Check if currently connected to broker"""
        pass
    
    @abstractmethod
    async def close_position(self, position_params: Dict) -> Dict:
        """Close a specific position"""
        pass
