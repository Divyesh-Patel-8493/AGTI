"""
Circuit Breaker Handler for Indian Markets
"""
import asyncio
from datetime import datetime, timedelta
from typing import Dict, List, Optional
import pandas as pd
from loguru import logger

from utils.alert_system import AlertSystem


class CircuitBreakerManager:
    """
    Manage market-wide and stock-specific circuit breakers for Indian markets
    
    NSE implements three levels of market-wide circuit breakers:
    - 10% movement: 45-minute halt if before 1pm, 15-minute halt if between 1-2:30pm, market closes if after 2:30pm
    - 15% movement: 1 hour 45-minute halt if before 1pm, 45-minute halt if between 1-2:30pm, market closes if after 2:30pm
    - 20% movement: Market closes for the day
    """
    def __init__(self, config: Dict, alert_system: AlertSystem):
        self.config = config
        self.alert_system = alert_system
        self.circuit_breakers = {}  # Store active circuit breakers
        self.index_levels = {}  # Store reference levels for indices
        self.recovery_queue = []  # Orders to process after circuit breaker ends
        
    async def initialize(self, broker_manager):
        """Initialize circuit breaker levels"""
        self.broker_manager = broker_manager
        
        # Get reference levels for indices (previous day close)
        await self._fetch_index_levels()
        logger.info(f"Initialized circuit breaker reference levels: {self.index_levels}")
        
    async def _fetch_index_levels(self):
        """Fetch reference levels for indices"""
        indices = ['NIFTY 50', 'NIFTY BANK', 'SENSEX']
        
        for index in indices:
            try:
                # Get previous day's closing price
                data = await self.broker_manager.get_historical_data(
                    symbol=index,
                    interval='day',
                    from_date=(datetime.now() - timedelta(days=5)).strftime('%Y-%m-%d'),
                    to_date=datetime.now().strftime('%Y-%m-%d')
                )
                
                if not data.empty:
                    # Previous day close (excluding today if market is open)
                    prev_close = data.iloc[-2]['close'] if len(data) > 1 else data.iloc[0]['close']
                    
                    # Calculate circuit breaker levels
                    self.index_levels[index] = {
                        'reference': prev_close,
                        'upper_10': prev_close * 1.10,
                        'lower_10': prev_close * 0.90,
                        'upper_15': prev_close * 1.15,
                        'lower_15': prev_close * 0.85,
                        'upper_20': prev_close * 1.20,
                        'lower_20': prev_close * 0.80
                    }
                    
            except Exception as e:
                logger.error(f"Error fetching reference level for {index}: {str(e)}")
    
    async def check_circuit_breakers(self, market_data: Dict) -> Dict:
        """
        Check if market-wide circuit breakers have been triggered
        
        Args:
            market_data: Dictionary with current index levels
            
        Returns:
            Dictionary with circuit breaker status
        """
        if not self.index_levels:
            await self._fetch_index_levels()
            
        results = {}
        
        # Check main indices
        for index, current_price in market_data.items():
            if index not in self.index_levels:
                continue
                
            reference = self.index_levels[index]
            percentage_change = (current_price - reference['reference']) / reference['reference'] * 100
            
            # Check for circuit breaker levels
            if current_price >= reference['upper_20'] or current_price <= reference['lower_20']:
                # 20% circuit breaker - market closes
                level = 3
                halt_minutes = 0  # Market closes for the day
                results[index] = {
                    'triggered': True,
                    'level': level,
                    'percentage_change': percentage_change,
                    'halt_minutes': halt_minutes,
                    'halt_until': None  # Market closed for the day
                }
                await self._handle_circuit_breaker(index, level, halt_minutes)
                
            elif current_price >= reference['upper_15'] or current_price <= reference['lower_15']:
                # 15% circuit breaker
                level = 2
                # Determine halt duration based on time of day
                now = datetime.now()
                if now.hour < 13:  # Before 1pm
                    halt_minutes = 105  # 1 hour 45 minutes
                elif now.hour == 13 or (now.hour == 14 and now.minute <= 30):  # Between 1pm and 2:30pm
                    halt_minutes = 45
                else:  # After 2:30pm
                    halt_minutes = 0  # Market closes for the day
                    
                halt_until = (now + timedelta(minutes=halt_minutes)) if halt_minutes > 0 else None
                
                results[index] = {
                    'triggered': True,
                    'level': level,
                    'percentage_change': percentage_change,
                    'halt_minutes': halt_minutes,
                    'halt_until': halt_until
                }
                await self._handle_circuit_breaker(index, level, halt_minutes)
                
            elif current_price >= reference['upper_10'] or current_price <= reference['lower_10']:
                # 10% circuit breaker
                level = 1
                # Determine halt duration based on time of day
                now = datetime.now()
                if now.hour < 13:  # Before 1pm
                    halt_minutes = 45
                elif now.hour == 13 or (now.hour == 14 and now.minute <= 30):  # Between 1pm and 2:30pm
                    halt_minutes = 15
                else:  # After 2:30pm
                    halt_minutes = 0  # Market closes for the day
                    
                halt_until = (now + timedelta(minutes=halt_minutes)) if halt_minutes > 0 else None
                
                results[index] = {
                    'triggered': True,
                    'level': level,
                    'percentage_change': percentage_change,
                    'halt_minutes': halt_minutes,
                    'halt_until': halt_until
                }
                await self._handle_circuit_breaker(index, level, halt_minutes)
                
            else:
                # No circuit breaker
                results[index] = {
                    'triggered': False,
                    'percentage_change': percentage_change
                }
                
        return results
    
    async def check_stock_circuit_breaker(self, symbol: str, current_price: float, reference_price: float) -> Dict:
        """
        Check if a stock-specific circuit breaker has been triggered
        
        Args:
            symbol: Stock symbol
            current_price: Current stock price
            reference_price: Reference price (usually previous day close)
            
        Returns:
            Dictionary with circuit breaker status
        """
        # Stock circuit limits (typically 5%, 10%, or 20% depending on price band)
        # This is a simplified version - actual implementation would need price bands from exchange
        percentage_change = (current_price - reference_price) / reference_price * 100
        
        # Default to 20% for all stocks (in reality this varies by stock)
        upper_limit = reference_price * 1.20
        lower_limit = reference_price * 0.80
        
        if current_price >= upper_limit or current_price <= lower_limit:
            # Circuit triggered - no more trading for the day
            if symbol not in self.circuit_breakers:
                self.circuit_breakers[symbol] = {
                    'triggered': True,
                    'timestamp': datetime.now(),
                    'price': current_price,
                    'reference': reference_price,
                    'percentage_change': percentage_change
                }
                
                # Send alert
                await self.alert_system.send_alert(
                    f"Circuit Breaker: {symbol}",
                    f"{symbol} hit circuit limit with {percentage_change:.2f}% move. Trading halted for the day.",
                    languages=['en', 'gu'],
                    priority='high'
                )
                
            return {
                'triggered': True,
                'percentage_change': percentage_change,
                'halt_until': None  # Halted for the day
            }
        else:
            return {
                'triggered': False,
                'percentage_change': percentage_change
            }
    
    async def _handle_circuit_breaker(self, index: str, level: int, halt_minutes: int):
        """
        Handle circuit breaker trigger
        
        Args:
            index: Index that triggered the circuit breaker
            level: Circuit breaker level (1, 2, or 3)
            halt_minutes: Duration of trading halt in minutes
        """
        # Send alert
        if halt_minutes > 0:
            halt_until = datetime.now() + timedelta(minutes=halt_minutes)
            message = (
                f"Circuit breaker level {level} triggered for {index}. "
                f"Trading halted for {halt_minutes} minutes until {halt_until.strftime('%H:%M:%S')}."
            )
            
            message_gujarati = (
                f"{index} માટે સર્કિટ બ્રેકર લેવલ {level} ટ્રિગર થયું. "
                f"ટ્રેડિંગ {halt_minutes} મિનિટ માટે {halt_until.strftime('%H:%M:%S')} સુધી રોકી દેવામાં આવ્યું છે."
            )
        else:
            message = f"Circuit breaker level {level} triggered for {index}. Market closed for the day."
            message_gujarati = f"{index} માટે સર્કિટ બ્રેકર લેવલ {level} ટ્રિગર થયું. આજે માટે માર્કેટ બંધ."
        
        await self.alert_system.send_alert(
            f"Market Circuit Breaker Level {level}",
            message,
            title_gujarati=f"માર્કેટ સર્કિટ બ્રેકર લેવલ {level}",
            message_gujarati=message_gujarati,
            languages=['en', 'gu'],
            priority='critical'
        )
        
        # Cancel pending orders
        try:
            # Use our broker manager to cancel all pending orders
            await self.broker_manager.cancel_all_pending_orders()
            
            # Log action
            logger.warning(f"Circuit breaker triggered: Canceled all pending orders due to {index} level {level} halt")
        except Exception as e:
            logger.error(f"Error canceling orders during circuit breaker: {str(e)}")
        
        # If market is closing for the day, square off positions
        if halt_minutes == 0:
            try:
                # Square off all positions
                # This is a protective measure that would be configurable in production
                # In some cases, clients may want to hold positions overnight instead
                if self.config.get('square_off_on_market_close', True):
                    await self.broker_manager.square_off_all_positions()
                    logger.warning("Circuit breaker: Market closed for the day, squared off all positions")
            except Exception as e:
                logger.error(f"Error squaring off positions during circuit breaker: {str(e)}")
