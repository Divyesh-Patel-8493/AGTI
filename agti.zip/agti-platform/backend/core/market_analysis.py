"""
Market Analysis Agents for options, news, and participant detection
"""
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import Dict, List, Optional

from core.agent_framework import Agent
from data.data_manager import DataManager
from brokers.broker_manager import BrokerManager


class OptionsAnalysisAgent(Agent):
    """
    Analyzes options chain data to identify trading opportunities
    """
    def __init__(self, config: Dict, data_manager: DataManager, broker_manager: BrokerManager):
        super().__init__(config)
        self.data_manager = data_manager
        self.broker_manager = broker_manager
        self.historical_volatility = {}
        self.symbols = config.get('symbols', ['NIFTY', 'BANKNIFTY'])
        
    def initialize(self):
        """Load historical data and calculate volatility metrics"""
        self.log("Initializing Options Analysis Agent")
        
        for symbol in self.symbols:
            try:
                data = self.data_manager.get_dataset(f"historical_{symbol}")
                if data is not None:
                    # Calculate 30-day historical volatility
                    returns = np.log(data['close'] / data['close'].shift(1)).dropna()
                    hv = returns.std() * np.sqrt(252)  # Annualized
                    self.historical_volatility[symbol] = hv
                    self.log(f"Calculated historical volatility for {symbol}: {hv:.4f}")
            except Exception as e:
                self.log(f"Error initializing data for {symbol}: {str(e)}", "error")
                
    async def execute_async(self):
        """Analyze options chain and identify trading opportunities"""
        for symbol in self.symbols:
            try:
                # Get current implied volatility
                iv_data = await self._get_current_implied_volatility(symbol)
                
                # Get historical volatility
                hv = self.historical_volatility.get(symbol, 0)
                
                if hv > 0 and symbol in iv_data:
                    iv = iv_data[symbol]
                    
                    # Calculate IV/HV ratio
                    iv_hv_ratio = iv / hv
                    
                    # Trading signals based on volatility discrepancy
                    if iv_hv_ratio < 0.8:
                        self.log(f"Potential buying opportunity for {symbol}: IV ({iv:.4f}) significantly lower than HV ({hv:.4f})")
                        await self._generate_options_signal(symbol, "BUY", iv_hv_ratio)
                    elif iv_hv_ratio > 1.2:
                        self.log(f"Caution for {symbol}: IV ({iv:.4f}) significantly higher than HV ({hv:.4f})")
            
            except Exception as e:
                self.log(f"Error analyzing options for {symbol}: {str(e)}", "error")
    
    async def _get_current_implied_volatility(self, symbol: str) -> Dict[str, float]:
        """Get current implied volatility from options chain"""
        try:
            options_chain = await self.data_manager.get_options_chain(symbol)
            
            # Calculate average IV of ATM options
            atm_options = self._filter_atm_options(options_chain, symbol)
            if atm_options.empty:
                return {}
                
            avg_iv = atm_options['implied_volatility'].mean()
            return {symbol: avg_iv}
            
        except Exception as e:
            self.log(f"Error getting IV data: {str(e)}", "error")
            return {}
    
    def _filter_atm_options(self, options_chain: pd.DataFrame, symbol: str) -> pd.DataFrame:
        """Filter options chain to get ATM options"""
        try:
            # Get current spot price
            spot_price = self.data_manager.get_ltp(symbol)
            
            # Find closest strikes
            options_chain['distance'] = abs(options_chain['strike'] - spot_price)
            atm_options = options_chain.nsmallest(3, 'distance')
            
            return atm_options
            
        except Exception as e:
            self.log(f"Error filtering ATM options: {str(e)}", "error")
            return pd.DataFrame()
    
    async def _generate_options_signal(self, symbol: str, action: str, iv_hv_ratio: float):
        """Generate and submit trading signal"""
        pass  # Implementation details to follow


class NewsSentimentAgent(Agent):
    """
    Monitors and analyzes news for sentiment and trading signals
    Supports both English and Gujarati languages
    """
    def __init__(self, config: Dict, data_manager: DataManager, language: str = 'en'):
        super().__init__(config)
        self.data_manager = data_manager
        self.language = language
        self.sentiment_threshold = config.get('sentiment_threshold', 0.7)
        self.symbols = config.get('symbols', ['RELIANCE', 'HDFCBANK', 'TCS'])
        
    def initialize(self):
        """Initialize NLP models and news sources"""
        self.log(f"Initializing News Sentiment Agent with language: {self.language}")
        
    async def execute_async(self):
        """Analyze latest news for sentiment and generate signals"""
        try:
            # Get latest news
            news_items = await self.data_manager.get_latest_news(
                symbols=self.symbols,
                language=self.language
            )
            
            if not news_items:
                return
                
            self.log(f"Analyzing {len(news_items)} news items")
            
            # Process each news item
            for item in news_items:
                sentiment_score = self._analyze_sentiment(item)
                
                if abs(sentiment_score) >= self.sentiment_threshold:
                    self.log(f"Strong sentiment detected: {sentiment_score:.2f} for news about {item['symbol']}")
                    await self._generate_news_signal(item, sentiment_score)
        
        except Exception as e:
            self.log(f"Error analyzing news: {str(e)}", "error")
    
    def _analyze_sentiment(self, news_item: Dict) -> float:
        """Analyze sentiment of news item (range -1 to 1)"""
        # This would typically use a pre-trained NLP model
        # For now, return a placeholder value
        return 0.5  # Slightly positive
    
    async def _generate_news_signal(self, news_item: Dict, sentiment_score: float):
        """Generate and submit trading signal based on news"""
        pass  # Implementation details to follow


class ParticipantDetectionAgent(Agent):
    """
    Detects institutional activity and "smart money" movements
    """
    def __init__(self, config: Dict, data_manager: DataManager):
        super().__init__(config)
        self.data_manager = data_manager
        self.threshold = config.get('activity_threshold', 2.0)
        self.symbols = config.get('symbols', ['NIFTY', 'BANKNIFTY'])
        
    def initialize(self):
        """Initialize detection parameters"""
        self.log("Initializing Participant Detection Agent")
        
    async def execute_async(self):
        """Detect unusual institutional activity"""
        for symbol in self.symbols:
            try:
                # Get OI and volume data
                oi_data = await self.data_manager.get_oi_data(symbol)
                
                if oi_data is None or oi_data.empty:
                    continue
                    
                # Look for unusual changes
                oi_change = self._calculate_oi_change(oi_data)
                
                if abs(oi_change) > self.threshold:
                    direction = "bullish" if oi_change > 0 else "bearish"
                    self.log(f"Detected significant {direction} institutional activity in {symbol}")
                    # Generate signal or alert
            
            except Exception as e:
                self.log(f"Error detecting institutional activity for {symbol}: {str(e)}", "error")
    
    def _calculate_oi_change(self, oi_data: pd.DataFrame) -> float:
        """Calculate normalized change in open interest"""
        try:
            # Calculate recent OI change vs historical average
            recent_oi = oi_data['oi'].iloc[-1]
            avg_oi = oi_data['oi'].mean()
            std_oi = oi_data['oi'].std()
            
            # Normalize change
            if std_oi > 0:
                return (recent_oi - avg_oi) / std_oi
            return 0
            
        except Exception as e:
            self.log(f"Error calculating OI change: {str(e)}", "error")
            return 0
