"""
Base Agent Framework for AGTI platform
"""
from abc import ABC, abstractmethod
import asyncio
from typing import Dict, Any, Optional
from loguru import logger


class Agent(ABC):
    """
    Abstract base class for all autonomous agents in the system
    """
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.name = self.__class__.__name__
        self.logger = logger.bind(agent=self.name)
        self.running = True

    @abstractmethod
    def initialize(self):
        """
        Initialize agent with necessary resources
        """
        pass

    @abstractmethod
    async def execute_async(self):
        """
        Execute agent's primary function (async version)
        """
        pass
    
    def execute(self):
        """
        Synchronous execution wrapper
        """
        loop = asyncio.get_event_loop()
        return loop.run_until_complete(self.execute_async())

    def log(self, message: str, level: str = "info"):
        """
        Log a message with agent context
        """
        log_method = getattr(self.logger, level)
        log_method(message)

    def shutdown(self):
        """
        Clean shutdown of agent resources
        """
        self.running = False
        self.log("Agent shutdown complete")

    async def health_check(self) -> Dict[str, Any]:
        """
        Report on agent's health status
        """
        return {
            "name": self.name,
            "status": "healthy" if self.running else "stopped",
            "config": self.config
        }
