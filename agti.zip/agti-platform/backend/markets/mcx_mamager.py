"""
MCX (Multi Commodity Exchange) Manager for commodity trading support
"""
import aiohttp
import asyncio
from datetime import datetime, timedelta
from typing import Dict, List, Optional
import pandas as pd
from loguru import logger

from utils.alert_system import AlertSystem


class MCXManager:
    """
    Handles MCX-specific market operations, commodity trading halts,
    and special market rules for the Indian commodity markets
    """
    def __init__(self, config: Dict, alert_system: AlertSystem):
        self.config = config
        self.alert_system = alert_system
        self.halt_cache = {}
        self.commodity_info = {}
        self.trade_session_end = {}  # End times for different commodities
    
    async def initialize(self):
        """Initialize MCX data and trading parameters"""
        await self._load_commodity_info()
        logger.info(f"Initialized MCX Manager with {len(self.commodity_info)} commodities")
    
    async def _load_commodity_info(self):
        """Load commodity information including trading hours and lot sizes"""
        # Default trading sessions for common commodities
        self.commodity_info = {
            'GOLD': {
                'lot_size': 100,  # grams
                'tick_size': 0.1,  # rupees
                'session_start': '09:00:00',
                'session_end': '23:30:00',
                'price_unit': 'per 10 grams'
            },
            'SILVER': {
                'lot_size': 30,  # kg
                'tick_size': 1.0,  # rupees
                'session_start': '09:00:00',
                'session_end': '23:30:00',
                'price_unit': 'per kg'
            },
            'CRUDEOIL': {
                'lot_size': 100,  # barrels
                'tick_size': 1.0,  # rupees
                'session_start': '09:00:00',
                'session_end': '23:30:00',
                'price_unit': 'per barrel'
            },
            'NATURALGAS': {
                'lot_size': 1250,  # mmBtu
                'tick_size': 0.1,  # rupees
                'session_start': '09:00:00',
                'session_end': '23:30:00',
                'price_unit': 'per mmBtu'
            },
            'COPPER': {
                'lot_size': 2500,  # kg
                'tick_size': 0.05,  # rupees
                'session_start': '09:00:00',
                'session_end': '23:30:00',
                'price_unit': 'per kg'
            }
        }
        
        # Try to get actual data from API
        try:
            # Placeholder for actual API call
            pass
        except Exception as e:
            logger.warning(f"Could not fetch commodity info from API, using defaults: {str(e)}")
    
    async def check_trading_halts(self, symbol: str) -> bool:
        """
        Check if a commodity is currently halted
        
        Args:
            symbol: Commodity symbol
            
        Returns:
            True if trading is halted, False otherwise
        """
        # Check cache first to avoid hammering the API
        if symbol in self.halt_cache:
            # Cache valid for 5 minutes
            if (datetime.now() - self.halt_cache[symbol]['timestamp']).seconds < 300:
                return self.halt_cache[symbol]['halted']
        
        try:
            # In a real system, this would call the MCX API
            # For now, using a simulated response
            is_halted = False
            
            # Update cache
            self.halt_cache[symbol] = {
                'halted': is_halted,
                'timestamp': datetime.now()
            }
            
            if is_halted:
                await self.alert_system.send_alert(
                    f"MCX Trading Halt: {symbol}",
                    f"{symbol} trading has been halted. All open orders will be cancelled.",
                    languages=['en', 'gu'],
                    priority='high'
                )
            
            return is_halted
            
        except Exception as e:
            logger.error(f"Error checking MCX trading halt for {symbol}: {str(e)}")
            return False  # Assume not halted if check fails for safety
    
    async def is_trading_hours(self, symbol: str) -> bool:
        """
        Check if the current time is within trading hours for a commodity
        
        Args:
            symbol: Commodity symbol
            
        Returns:
            True if within trading hours, False otherwise
        """
        now = datetime.now().time()
        
        if symbol not in self.commodity_info:
            # Default trading hours if symbol not found
            start_time = datetime.strptime('09:00:00', '%H:%M:%S').time()
            end_time = datetime.strptime('23:30:00', '%H:%M:%S').time()
        else:
            start_time = datetime.strptime(self.commodity_info[symbol]['session_start'], '%H:%M:%S').time()
            end_time = datetime.strptime(self.commodity_info[symbol]['session_end'], '%H:%M:%S').time()
        
        # Check if current time is within trading hours
        if start_time <= now <= end_time:
            return True
        return False
    
    def get_lot_size(self, symbol: str) -> int:
        """
        Get the lot size for a commodity
        
        Args:
            symbol: Commodity symbol
            
        Returns:
            Lot size
        """
        if symbol in self.commodity_info:
            return self.commodity_info[symbol]['lot_size']
        return 1  # Default lot size
    
    def get_tick_size(self, symbol: str) -> float:
        """
        Get the tick size for a commodity
        
        Args:
            symbol: Commodity symbol
            
        Returns:
            Tick size
        """
        if symbol in self.commodity_info:
            return self.commodity_info[symbol]['tick_size']
        return 0.05  # Default tick size
    
    async def handle_session_end(self, symbol: str):
        """
        Handle actions needed at the end of a trading session
        
        Args:
            symbol: Commodity symbol
        """
        try:
            # In production, this would check for any open positions
            # and take appropriate action (e.g., square off)
            
            logger.info(f"MCX trading session ending for {symbol}")
            
            # Send alert
            await self.alert_system.send_alert(
                f"MCX Session End: {symbol}",
                f"Trading session for {symbol} is ending. Please check any open positions.",
                languages=['en', 'gu'],
                priority='normal'
            )
            
        except Exception as e:
            logger.error(f"Error handling MCX session end for {symbol}: {str(e)}")