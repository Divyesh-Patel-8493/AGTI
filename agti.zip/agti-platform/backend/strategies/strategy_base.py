"""
Base Strategy Class for AGTI platform
"""
from abc import ABC, abstractmethod
import pandas as pd
from typing import Dict, List, Optional
from datetime import datetime, timedelta
from loguru import logger


class BaseStrategy(ABC):
    """
    Abstract base class for all trading strategies
    """
    def __init__(self, config: Dict, broker):
        self.config = config
        self.broker = broker
        self.name = self.__class__.__name__
        self.positions = pd.DataFrame()
        self.historical_data = pd.DataFrame()
        self.logger = logger.bind(strategy=self.name)

    @abstractmethod
    def calculate_signals(self) -> pd.DataFrame:
        """Generate trading signals based on strategy logic"""
        pass

    @abstractmethod
    def risk_management(self, signals: pd.DataFrame) -> pd.DataFrame:
        """Apply risk management filters to signals"""
        pass

    def execute(self) -> List[Dict]:
        """Main execution method for the strategy"""
        try:
            signals = self.calculate_signals()
            if signals.empty:
                self.logger.debug("No signals generated")
                return []
                
            filtered_signals = self.risk_management(signals)
            if filtered_signals.empty:
                self.logger.debug("All signals filtered out by risk management")
                return []
                
            return self._generate_orders(filtered_signals)
        except Exception as e:
            self.logger.error(f"Error executing strategy: {str(e)}")
            return []

    def _generate_orders(self, signals: pd.DataFrame) -> List[Dict]:
        """Convert signals to order dictionaries"""
        orders = []
        for _, row in signals.iterrows():
            try:
                orders.append({
                    'symbol': row['symbol'],
                    'exchange': 'NFO' if 'OPT' in row['symbol'] or 'FUT' in row['symbol'] else 'NSE',
                    'transaction_type': row.get('action', 'BUY'),  # Default to BUY for options
                    'quantity': self._calculate_quantity(row),
                    'order_type': row.get('order_type', 'LIMIT'),
                    'product': 'MIS' if self.config.get('intraday', True) else 'NRML',
                    'price': row.get('entry_price', 0),
                    'trigger_price': row.get('trigger_price'),
                    'strategy': self.name,
                    'timestamp': datetime.now().isoformat()
                })
            except Exception as e:
                self.logger.error(f"Error generating order from signal: {str(e)}")
                
        return orders

    def _calculate_quantity(self, signal: pd.Series) -> int:
        """Calculate position size based on risk parameters"""
        try:
            capital = self.config.get('capital', 5000)  # ₹5,000 default
            
            risk_per_trade = self.config.get('risk_per_trade', 0.02)  # 2% of capital by default
            stop_loss = signal.get('stop_loss')
            entry = signal.get('entry_price')
            
            if stop_loss is None or entry is None or entry == 0:
                # If no stop loss or entry price, use fixed position size
                return max(1, int(capital * risk_per_trade / entry)) if entry else 1
            
            risk_amount = capital * risk_per_trade
            risk_per_unit = abs(entry - stop_loss)
            
            if risk_per_unit <= 0:
                return 1
                
            quantity = int(risk_amount / risk_per_unit)
            
            # Ensure minimum quantity
            return max(1, quantity)
            
        except Exception as e:
            self.logger.error(f"Error calculating quantity: {str(e)}")
            return 1
