"""
Zero to Hero Options Strategy

This strategy focuses on finding low-cost options with potential for exponential returns.
It looks for options with low implied volatility relative to historical volatility,
especially those with high leverage and near-term expiries.
"""
from datetime import datetime, timedelta
from typing import Dict, List
import pandas as pd
import numpy as np

from backend.strategies.strategy_base import BaseStrategy
from backend.utils.news_analyzer import NewsAnalyzer


class ZeroToHeroStrategy(BaseStrategy):
    def __init__(self, config: Dict, broker, data_manager):
        super().__init__(config, broker)
        self.data_manager = data_manager
        self.news_analyzer = NewsAnalyzer()
        self.impact_threshold = config.get('impact_threshold', 0.8)
        self.max_days_to_expiry = config.get('max_days_to_expiry', 7)
        self.max_premium = config.get('max_premium', 100)  # ₹100 maximum premium
        self.min_oi = config.get('min_oi', 1000)  # Minimum open interest

    def calculate_signals(self) -> pd.DataFrame:
        """Identify high-impact news events and potential option plays"""
        signals = pd.DataFrame()
        
        try:
            # Get high-impact news events
            news_events = self.news_analyzer.get_today_events()
            high_impact_news = [
                event for event in news_events 
                if event.get('impact_score', 0) >= self.impact_threshold
            ]
            
            if not high_impact_news:
                self.logger.info("No high-impact news events found")
                return signals
            
            # Process each high-impact news event
            for event in high_impact_news:
                symbol = event.get('symbol')
                if not symbol:
                    continue
                    
                # Get option instruments for this symbol
                option_details = self._get_option_instruments(symbol)
                
                if option_details.empty:
                    self.logger.warning(f"No option details found for {symbol}")
                    continue
                
                # Generate signals based on event
                event_signals = self._generate_event_signals(event, option_details)
                
                # Append to main signals DataFrame
                signals = pd.concat([signals, event_signals])
            
            self.logger.info(f"Generated {len(signals)} zero-to-hero signals")
            return signals
            
        except Exception as e:
            self.logger.error(f"Error calculating zero-to-hero signals: {str(e)}")
            return pd.DataFrame()

    def _get_option_instruments(self, symbol: str) -> pd.DataFrame:
        """Get relevant options contracts for the symbol"""
        try:
            # Get options chain from data manager
            options_chain = self.data_manager.get_dataset(f"options_chain_{symbol}")
            
            if options_chain is None or options_chain.empty:
                # Try to load from data manager
                options_chain = asyncio.run(self.data_manager.get_options_chain(symbol))
                
                # Store for future use
                if not options_chain.empty:
                    self.data_manager.store_dataset(f"options_chain_{symbol}", options_chain)
            
            if options_chain.empty:
                return pd.DataFrame()
                
            # Filter by days to expiry
            if 'days_to_expiry' in options_chain.columns:
                options_chain = options_chain[
                    options_chain['days_to_expiry'] <= self.max_days_to_expiry
                ]
            
            # Filter by premium (last price)
            if 'last_price' in options_chain.columns:
                options_chain = options_chain[
                    options_chain['last_price'] <= self.max_premium
                ]
            
            # Filter by open interest
            if 'oi' in options_chain.columns:
                options_chain = options_chain[
                    options_chain['oi'] >= self.min_oi
                ]
            
            return options_chain
            
        except Exception as e:
            self.logger.error(f"Error getting option instruments for {symbol}: {str(e)}")
            return pd.DataFrame()

        def _get_nearest_expiry(self) -> str:
        """Get nearest Thursday expiry date"""
        today = datetime.now().date()
        next_thursday = today + timedelta((3 - today.weekday()) % 7)
        return next_thursday.strftime('%Y-%m-%d')

    def _get_atm_strike(self, symbol: str) -> float:
        """Get at-the-money strike price for a symbol"""
        try:
            # Get current spot price
            spot_price = self.data_manager.get_ltp(symbol)
            
            if spot_price <= 0:
                self.logger.warning(f"Invalid spot price for {symbol}: {spot_price}")
                return 0
                
            # Round to nearest strike
            strike_step = self.config.get('strike_step', 50)  # Default strike step for indices
            
            # For stocks, use a different strike step
            if symbol not in ['NIFTY', 'BANKNIFTY', 'FINNIFTY']:
                strike_step = self.config.get('stock_strike_step', 20)
                
            atm_strike = round(spot_price / strike_step) * strike_step
            return atm_strike
            
        except Exception as e:
            self.logger.error(f"Error getting ATM strike for {symbol}: {str(e)}")
            return 0

    def _generate_event_signals(self, event: Dict, options: pd.DataFrame) -> pd.DataFrame:
        """Generate signals based on event type and option chain"""
        signals = []
        atm_strike = self._get_atm_strike(event['symbol'])
        
        if atm_strike <= 0:
            return pd.DataFrame()
            
        try:
            # Determine option type based on event sentiment
            sentiment = event.get('sentiment', 0)
            option_type = 'CE' if sentiment > 0 else 'PE'
            
            # Filter options by strike and type
            filtered_options = options[
                (options['strike'] == atm_strike) & 
                (options['option_type'] == option_type)
            ]
            
            if filtered_options.empty:
                return pd.DataFrame()
                
            # Sort by expiry (nearest first) and select the first one
            filtered_options = filtered_options.sort_values('expiry' if 'expiry' in filtered_options.columns else 'days_to_expiry')
            opt = filtered_options.iloc[0]
            
            # Create signal
            signal = {
                'symbol': opt['symbol'],
                'entry_price': opt['last_price'],
                'stop_loss': opt['last_price'] * 0.7,  # 30% SL
                'target_price': opt['last_price'] * 2,  # 100% target
                'event': event['title'],
                'impact_score': event['impact_score'],
                'expiry': opt['expiry'] if 'expiry' in opt else self._get_nearest_expiry(),
                'option_type': option_type,
                'action': 'BUY'
            }
            
            signals.append(signal)
            self.logger.info(f"Generated zero-to-hero signal for {event['symbol']} based on event: {event['title']}")
            
            return pd.DataFrame(signals)
            
        except Exception as e:
            self.logger.error(f"Error generating event signals: {str(e)}")
            return pd.DataFrame()

    def risk_management(self, signals: pd.DataFrame) -> pd.DataFrame:
        """Apply risk management filters to signals"""
        if signals.empty:
            return signals
            
        try:
            # 1. Check capital allocation
            max_capital_per_trade = self.config.get('max_capital_per_trade', 0.2)  # 20% max per trade
            capital = self.config.get('capital', 5000)  # ₹5,000 default
            max_amount = capital * max_capital_per_trade
            
            # Filter out signals that would exceed max capital
            signals['required_capital'] = signals['entry_price'] * signals['quantity'] if 'quantity' in signals.columns else signals['entry_price'] * 1
            signals = signals[signals['required_capital'] <= max_amount]
            
            # 2. Check maximum number of concurrent trades
            max_positions = self.config.get('max_positions', 3)
            current_positions = len(self.broker.get_positions())
            
            if current_positions >= max_positions:
                self.logger.warning(f"Maximum positions reached ({max_positions}), no new signals generated")
                return pd.DataFrame()
                
            positions_left = max_positions - current_positions
            signals = signals.head(positions_left)
            
            # 3. Check market conditions
            market_vix = self.data_manager.get_dataset('vix_level')
            if market_vix is not None and market_vix > self.config.get('max_vix', 30):
                self.logger.warning(f"Market VIX too high ({market_vix}), reducing position size")
                # Reduce position size by half during high volatility
                signals['quantity'] = signals['quantity'] // 2 if 'quantity' in signals.columns else 1
            
            return signals
            
        except Exception as e:
            self.logger.error(f"Error in risk management: {str(e)}")
            return pd.DataFrame()
