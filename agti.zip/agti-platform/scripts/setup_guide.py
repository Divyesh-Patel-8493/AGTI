#!/usr/bin/env python3
"""
Setup Guide for AGTI Platform
Helps users configure their trading environment
"""
import os
import sys
import yaml
import json
import getpass
from datetime import datetime
import time
import random

# ASCII art logo
LOGO = """
    █████╗  ██████╗ ████████╗██╗
   ██╔══██╗██╔════╝ ╚══██╔══╝██║
   ███████║██║  ███╗   ██║   ██║
   ██╔══██║██║   ██║   ██║   ██║
   ██║  ██║╚██████╔╝   ██║   ██║
   ╚═╝  ╚═╝ ╚═════╝    ╚═╝   ╚═╝
                                
  Autonomous Global Trading Intelligence
"""

# Welcome message
WELCOME = """
Welcome to the AGTI Platform setup guide!

This script will help you configure your trading environment
for the Indian market with a focus on options trading.

Let's get started!
"""

def clear_screen():
    """Clear the terminal screen"""
    os.system('cls' if os.name == 'nt' else 'clear')

def print_header():
    """Print the header with logo"""
    clear_screen()
    print("\033[94m" + LOGO + "\033[0m")
    print(WELCOME)

def input_with_default(prompt, default=None):
    """Get user input with a default value"""
    if default:
        user_input = input(f"{prompt} [{default}]: ")
        return user_input if user_input else default
    return input(prompt + ": ")

def create_config_dir():
    """Create configuration directory if it doesn't exist"""
    config_dir = os.path.join(os.getcwd(), 'config')
    os.makedirs(config_dir, exist_ok=True)
    
    # Create subdirectories
    for subdir in ['environments', 'strategies', 'brokers', 'risk']:
        os.makedirs(os.path.join(config_dir, subdir), exist_ok=True)
    
    return config_dir

def configure_broker():
    """Configure broker settings"""
    print("\n\033[1m=== Broker Configuration ===\033[0m")
    
    brokers = {
        '1': 'zerodha',
        '2': 'fyers',
        '3': 'dhan',
        '4': 'paper_trading'
    }
    
    print("Select your broker:")
    for key, broker in brokers.items():
        print(f"{key}. {broker.capitalize()}")
    
    broker_choice = input("\nEnter your choice (1-4) [4]: ") or "4"
    selected_broker = brokers.get(broker_choice, 'paper_trading')
    
    broker_config = {
        'enabled': True
    }
    
    if selected_broker == 'paper_trading':
        print("\nConfiguring Paper Trading (simulation mode)")
        
        broker_config.update({
            'initial_capital': float(input_with_default("Initial capital (INR)", "5000")),
            'slippage': float(input_with_default("Simulated slippage (0.001 = 0.1%)", "0.001")),
            'execution_delay_ms': int(input_with_default("Simulated execution delay (ms)", "250"))
        })
    else:
        print(f"\nConfiguring {selected_broker.capitalize()}")
        
        if selected_broker == 'zerodha':
            broker_config.update({
                'api_key': input("Enter your Zerodha API Key: "),
                'access_token': getpass.getpass("Enter your Zerodha Access Token: ")
            })
        elif selected_broker == 'fyers':
            broker_config.update({
                'app_id': input("Enter your Fyers App ID: "),
                'access_token': getpass.getpass("Enter your Fyers Access Token: ")
            })
        elif selected_broker == 'dhan':
            broker_config.update({
                'client_id': input("Enter your Dhan Client ID: "),
                'access_token': getpass.getpass("Enter your Dhan Access Token: ")
            })
    
    return selected_broker, broker_config

def configure_strategies():
    """Configure trading strategies"""
    print("\n\033[1m=== Strategy Configuration ===\033[0m")
    
    strategies = {
        'zero_to_hero': {
            'description': 'Find low-cost options with exponential return potential',
            'enabled': True,
            'max_positions': 3,
            'risk_per_trade': 0.02,
            'impact_threshold': 0.8,
            'max_days_to_expiry': 7,
            'max_premium': 100  # ₹100 maximum premium
        },
        'volatility_based': {
            'description': 'Exploit IV-HV discrepancy for options trading',
            'enabled': True,
            'risk_per_trade': 0.02,
            'iv_hv_threshold': 0.8,
            'max_positions': 2
        },
        'breakout': {
            'description': 'Act on significant support/resistance breaks',
            'enabled': False,
            'lookback_period': 20,
            'confirmation_bars': 3
        },
        'vwap': {
            'description': 'Trade around volume-weighted average price levels',
            'enabled': False,
            'deviation_threshold': 0.01,
            'mean_reversion_factor': 0.5
        }
    }
    
    print("Available strategies:")
    for i, (name, details) in enumerate(strategies.items(), 1):
        status = "\033[92mEnabled\033[0m" if details['enabled'] else "\033[91mDisabled\033[0m"
        print(f"{i}. {name.replace('_', ' ').title()} [{status}]")
        print(f"   {details['description']}")
    
    print("\nYou can enable/disable strategies or leave the defaults")
    print("For this setup, we'll use the default strategy configuration")
    customize = input("\nCustomize strategies? (y/n) [n]: ").lower() == 'y'
    
    if customize:
        for name, details in strategies.items():
            choice = input(f"Enable {name.replace('_', ' ').title()}? (y/n) [{details['enabled'] and 'y' or 'n'}]: ").lower()
            if choice:
                strategies[name]['enabled'] = choice == 'y'
    
    return strategies

def configure_risk():
    """Configure risk management parameters"""
    print("\n\033[1m=== Risk Management Configuration ===\033[0m")
    
    risk_config = {
        'max_capital_per_trade': float(input_with_default("Maximum capital per trade (as ratio of total capital)", "0.20")),
        'max_daily_loss': float(input_with_default("Maximum daily loss (as ratio of total capital)", "0.05")),
        'max_drawdown': float(input_with_default("Maximum total drawdown (as ratio of total capital)", "0.15")),
        'circuit_breaker_enabled': input_with_default("Enable system circuit breaker? (y/n)", "y").lower() == 'y'
    }
    
    return risk_config

def configure_alerts():
    """Configure alert settings"""
    print("\n\033[1m=== Alert Configuration ===\033[0m")
    
    alert_config = {
        'languages': ['en']
    }
    
    # Ask about Gujarati support
    if input_with_default("Enable Gujarati language support? (y/n)", "n").lower() == 'y':
        alert_config['languages'].append('gu')
    
    # Email alerts
    if input_with_default("Configure email alerts? (y/n)", "n").lower() == 'y':
        alert_config['email'] = {
            'enabled': True,
            'smtp_server': input_with_default("SMTP Server", "smtp.gmail.com"),
            'smtp_port': int(input_with_default("SMTP Port", "587")),
            'username': input("SMTP Username: "),
            'password': getpass.getpass("SMTP Password: "),
            'from': input_with_default("From Email", "alerts@agti.com"),
            'use_tls': True,
            'recipients': [input("Recipient Email: ")]
        }
    else:
        alert_config['email'] = {'enabled': False}
    
    # Telegram alerts
    if input_with_default("Configure Telegram alerts? (y/n)", "n").lower() == 'y':
        alert_config['telegram'] = {
            'enabled': True,
            'bot_token': input("Telegram Bot Token: "),
            'chat_ids': [int(input("Telegram Chat ID: "))]
        }
    else:
        alert_config['telegram'] = {'enabled': False}
    
    return alert_config

def create_production_config(selected_broker, broker_config, strategies, risk_config, alert_config):
    """Create production configuration file"""
    config = {
        'log_level': 'INFO',
        'execution_interval_seconds': 60,  # Run main loop every minute
        
        'markets': {
            'india': {
                'initial_capital': 5000,  # ₹5,000
                'nse_symbols': [
                    'NIFTY50',
                    'BANKNIFTY', 
                    'RELIANCE',
                    'HDFCBANK',
                    'TCS'
                ],
                'brokers': [selected_broker]
            }
        },
        
        'data': {
            'historical': {
                'storage_path': 'backend/data/historical',
                'india': {
                    'nse': 'backend/data/historical/india/nse',
                    'bse': 'backend/data/historical/india/bse',
                    'mcx': 'backend/data/historical/india/mcx'
                }
            },
            'realtime': {
                'sources': [
                    {
                        'provider': selected_broker,
                        'interval': '1m'
                    }
                ]
            }
        },
        
        'brokers': {
            selected_broker: broker_config
        },
        
        'alerts': alert_config,
        
        'agents': {
            'options_analysis': {
                'enabled': strategies['zero_to_hero']['enabled'] or strategies['volatility_based']['enabled'],
                'max_positions': max(strategies['zero_to_hero'].get('max_positions', 3), 
                                    strategies['volatility_based'].get('max_positions', 2)),
                'risk_per_trade': strategies['zero_to_hero'].get('risk_per_trade', 0.02),
                'iv_hv_threshold': strategies['volatility_based'].get('iv_hv_threshold', 0.8),
                'symbols': ['NIFTY', 'BANKNIFTY']
            },
            'news_sentiment': {
                'enabled': strategies['zero_to_hero']['enabled'],
                'sentiment_threshold': 0.7,
                'sources': [
                    'moneycontrol',
                    'economic_times',
                    'business_standard'
                ],
                'languages': alert_config['languages']
            },
            'risk_management': {
                'enabled': True,
                'max_daily_loss': risk_config['max_daily_loss'],
                'stop_loss_pct': 0.10,  # 10% stop loss
                'max_position_size': risk_config['max_capital_per_trade'],
                'circuit_breaker_enabled': risk_config['circuit_breaker_enabled'],
                'max_drawdown': risk_config['max_drawdown']
            },
            'options_execution': {
                'enabled': True,
                'allow_only_buy': True,  # Only buy options (no selling/shorting)
                'max_premium_percent': 0.05,  # Maximum 5% of capital per option
                'expiry_days_cutoff': 3  # Don't hold options with less than 3 days to expiry
            },
        }
    }
    
    return config

def create_development_config(production_config):
    """Create development configuration file"""
    dev_config = {
        'extends': 'production.yaml',
        'log_level': 'DEBUG',
        'execution_interval_seconds': 10,  # Faster execution for testing
        
        'simulation': {
            'enabled': True,
            'price_volatility': 0.02,  # 2% daily volatility
            'market_bias': 0.001,  # Slight upward bias (0.1% daily)
            'tick_interval_ms': 500  # Tick every 500ms
        },
        
        'brokers': {
            'paper_trading': {
                'enabled': True,
                'initial_capital': 5000,
                'slippage': 0.001,  # 0.1% slippage
                'execution_delay_ms': 250  # Simulated execution delay
            }
        },
        
        'data': {
            'use_cached_historical': True,
            'generate_mock_realtime': True
        },
        
        'debug': {
            'log_all_signals': True,
            'log_all_orders': True,
            'save_charts': True,
            'save_path': 'debug/charts/',
            'profile_performance': True
        }
    }
    
    # If not using paper trading in production, disable other brokers in dev
    for broker in production_config['brokers']:
        if broker != 'paper_trading':
            dev_config['brokers'][broker] = {'enabled': False}
    
    return dev_config

def save_config_files(config_dir, production_config, development_config):
    """Save configuration files"""
    # Production config
    prod_path = os.path.join(config_dir, 'environments', 'production.yaml')
    with open(prod_path, 'w') as f:
        yaml.dump(production_config, f, default_flow_style=False)
    
    # Development config
    dev_path = os.path.join(config_dir, 'environments', 'development.yaml')
    with open(dev_path, 'w') as f:
        yaml.dump(development_config, f, default_flow_style=False)
    
    print(f"\nConfiguration files saved to:")
    print(f"- {prod_path}")
    print(f"- {dev_path}")

def create_guide_file():
    """Create a guide file for users"""
    guide_content = # AGTI Platform - Live Market Testing Guide

## Getting Started

This guide explains how to test the AGTI (Autonomous Global Trading Intelligence) platform in live markets.

### Prerequisites

1. A funded trading account with one of the supported brokers:
   - Zerodha
   - Fyers
   - Dhan

2. API credentials from your broker
   - For Zerodha: API Key and Access Token
   - For Fyers: App ID and Access Token
   - For Dhan: Client ID and Access Token

3. Minimum ₹5,000 in your trading account

### Configuration Guide

#### 1. Broker Setup

Edit `config/environments/production.yaml` to configure your broker:

```yaml
brokers:
  zerodha:  # Change to your broker (zerodha, fyers, or dhan)
    api_key: "YOUR_API_KEY"  # Enter your API key
    access_token: "YOUR_ACCESS_TOKEN"  # Enter your access token
    enabled: true


def main():
    """Main setup function"""
    print_header()
    
    # Create config directory
    config_dir = create_config_dir()
    
    # Interactive setup
    selected_broker, broker_config = configure_broker()
    strategies = configure_strategies()
    risk_config = configure_risk()
    alert_config = configure_alerts()
    
    # Create configuration files
    production_config = create_production_config(
        selected_broker,
        broker_config,
        strategies,
        risk_config,
        alert_config
    )
    
    development_config = create_development_config(production_config)
    
    # Save configuration files
    save_config_files(config_dir, production_config, development_config)
    
    # Create guide file
    create_guide_file()
    
    # Final steps
    print("\n\033[1m=== Setup Complete ===\033[0m")
    print("\nYour AGTI platform is now configured and ready to use!")
    print("\nTo start in development mode (paper trading):")
    print("  python backend/main.py --config=config/environments/development.yaml")
    print("\nTo start in production mode (live trading):")
    print("  python backend/main.py --config=config/environments/production.yaml")
    
    print("\nPlease review the LIVE_MARKET_GUIDE.txt file for important")
    print("information about testing in live markets.")
    
    print("\n\033[93mRemember: Start with small position sizes and monitor")
    print("the system closely during the first few days of trading.\033[0m")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\nSetup interrupted. No changes were saved.")
        sys.exit(1)
    except Exception as e:
        print(f"\n\033[91mError during setup: {str(e)}\033[0m")
        sys.exit(1)
